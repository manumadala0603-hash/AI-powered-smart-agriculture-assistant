/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { SlideDeck } from './components/SlideDeck';
import { LiveAssistantView } from './components/assistant/LiveAssistantView';
import { Slide1Title } from './components/slides/Slide1Title';
import { Slide2Problem } from './components/slides/Slide2Problem';
import { Slide3Challenges } from './components/slides/Slide3Challenges';
import { Slide4Solution } from './components/slides/Slide4Solution';
import { Slide5Features } from './components/slides/Slide5Features';
import { Slide6HowItWorks } from './components/slides/Slide6HowItWorks';
import { Slide7Impact } from './components/slides/Slide7Impact';
import { Slide8Conclusion } from './components/slides/Slide8Conclusion';

export default function App() {
  const [currentMode, setMode] = useState<'slides' | 'demo'>('slides');
  const [activeSlide, setActiveSlide] = useState<number>(1);

  const handleOpenLiveDemo = () => {
    setMode('demo');
  };

  const handleBackToSlides = () => {
    setMode('slides');
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans">
      {/* 3-Zone Top Bar Navigation */}
      <Navbar
        currentMode={currentMode}
        setMode={setMode}
        activeSlide={activeSlide}
        setActiveSlide={setActiveSlide}
        onOpenLiveDemo={handleOpenLiveDemo}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        {currentMode === 'slides' ? (
          <SlideDeck
            activeSlide={activeSlide}
            setActiveSlide={setActiveSlide}
            onOpenLiveDemo={handleOpenLiveDemo}
          />
        ) : (
          <LiveAssistantView onBackToSlides={handleBackToSlides} />
        )}
      </main>

      {/* Printable All-Slides Document (Only active when printing via window.print) */}
      <div className="hidden print:block space-y-8 p-4">
        <div className="print-page-break">
          <Slide1Title onOpenLiveDemo={() => {}} onNextSlide={() => {}} />
        </div>
        <div className="print-page-break">
          <Slide2Problem onNextSlide={() => {}} />
        </div>
        <div className="print-page-break">
          <Slide3Challenges onNextSlide={() => {}} />
        </div>
        <div className="print-page-break">
          <Slide4Solution onOpenLiveDemo={() => {}} onNextSlide={() => {}} />
        </div>
        <div className="print-page-break">
          <Slide5Features onOpenLiveDemo={() => {}} onNextSlide={() => {}} />
        </div>
        <div className="print-page-break">
          <Slide6HowItWorks onOpenLiveDemo={() => {}} onNextSlide={() => {}} />
        </div>
        <div className="print-page-break">
          <Slide7Impact onNextSlide={() => {}} />
        </div>
        <div className="print-page-break">
          <Slide8Conclusion onOpenLiveDemo={() => {}} onResetToSlide1={() => {}} />
        </div>
      </div>
    </div>
  );
}
