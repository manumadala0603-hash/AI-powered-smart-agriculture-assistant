import React from 'react';
import { Presentation, Sparkles, MonitorPlay } from 'lucide-react';

interface NavbarProps {
  currentMode: 'slides' | 'demo';
  setMode: (mode: 'slides' | 'demo') => void;
  activeSlide: number;
  setActiveSlide: (slide: number) => void;
  onOpenLiveDemo: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentMode,
  setMode,
  activeSlide,
  setActiveSlide,
  onOpenLiveDemo,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-stone-800 bg-stone-950/90 backdrop-blur-md px-6 py-3.5 transition-colors no-print">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => {
            setMode('slides');
            setActiveSlide(1);
          }}
          className="text-lg font-bold tracking-tight text-white hover:text-emerald-400 transition-colors cursor-pointer text-left font-display"
        >
          SmartAgri Assistant
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-300">
          <button
            onClick={() => {
              setMode('slides');
              setActiveSlide(1);
            }}
            className={`transition-colors cursor-pointer hover:text-white ${
              currentMode === 'slides' && activeSlide === 1 ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => {
              setMode('slides');
              setActiveSlide(2);
            }}
            className={`transition-colors cursor-pointer hover:text-white ${
              currentMode === 'slides' && activeSlide === 2 ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            Problem
          </button>
          <button
            onClick={() => {
              setMode('slides');
              setActiveSlide(4);
            }}
            className={`transition-colors cursor-pointer hover:text-white ${
              currentMode === 'slides' && activeSlide === 4 ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            AI Solution
          </button>
          <button
            onClick={() => {
              setMode('slides');
              setActiveSlide(5);
            }}
            className={`transition-colors cursor-pointer hover:text-white ${
              currentMode === 'slides' && activeSlide === 5 ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            Key Features
          </button>
          <button
            onClick={() => {
              setMode('slides');
              setActiveSlide(6);
            }}
            className={`transition-colors cursor-pointer hover:text-white ${
              currentMode === 'slides' && activeSlide === 6 ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            How It Works
          </button>
          <button
            onClick={() => {
              setMode('slides');
              setActiveSlide(7);
            }}
            className={`transition-colors cursor-pointer hover:text-white ${
              currentMode === 'slides' && activeSlide === 7 ? 'text-emerald-400 font-semibold' : ''
            }`}
          >
            Impact
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setMode('slides')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              currentMode === 'slides'
                ? 'bg-stone-800 text-stone-100 border border-stone-700 shadow-xs'
                : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Switch to Hackathon Slide Deck View"
          >
            <Presentation className="w-3.5 h-3.5 text-emerald-400" />
            <span>Pitch Deck</span>
          </button>

          <button
            onClick={() => {
              setMode('demo');
              onOpenLiveDemo();
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-colors cursor-pointer whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Launch Live AI Demo</span>
          </button>
        </div>
      </div>
    </header>
  );
};
