import React, { useState, useEffect } from 'react';
import { SLIDES_DATA } from '../data/slidesData';
import { Slide1Title } from './slides/Slide1Title';
import { Slide2Problem } from './slides/Slide2Problem';
import { Slide3Challenges } from './slides/Slide3Challenges';
import { Slide4Solution } from './slides/Slide4Solution';
import { Slide5Features } from './slides/Slide5Features';
import { Slide6HowItWorks } from './slides/Slide6HowItWorks';
import { Slide7Impact } from './slides/Slide7Impact';
import { Slide8Conclusion } from './slides/Slide8Conclusion';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  FileText,
  Clock,
  LayoutGrid,
  Printer,
  Sparkles,
  Play,
  Pause,
  RotateCcw,
} from 'lucide-react';

interface SlideDeckProps {
  activeSlide: number;
  setActiveSlide: (slide: number) => void;
  onOpenLiveDemo: () => void;
}

export const SlideDeck: React.FC<SlideDeckProps> = ({
  activeSlide,
  setActiveSlide,
  onOpenLiveDemo,
}) => {
  const [showNotes, setShowNotes] = useState<boolean>(false);
  const [showGrid, setShowGrid] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Pitch Timer state (seconds)
  const [timerSeconds, setTimerSeconds] = useState<number>(180); // 3 minutes standard pitch
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds]);

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleNext = () => {
    if (activeSlide < 8) setActiveSlide(activeSlide + 1);
  };

  const handlePrev = () => {
    if (activeSlide > 1) setActiveSlide(activeSlide - 1);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in input or textarea
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        handlePrev();
      } else if (e.key === 'n' || e.key === 'N') {
        setShowNotes((prev) => !prev);
      } else if (e.key === 'g' || e.key === 'G') {
        setShowGrid((prev) => !prev);
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeSlide]);

  const currentSlideData = SLIDES_DATA.find((s) => s.number === activeSlide) || SLIDES_DATA[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-col justify-between min-h-[calc(100vh-70px)]">
      {/* Slide Canvas Container */}
      <div className="relative w-full transition-all">
        {activeSlide === 1 && (
          <Slide1Title onOpenLiveDemo={onOpenLiveDemo} onNextSlide={handleNext} />
        )}
        {activeSlide === 2 && <Slide2Problem onNextSlide={handleNext} />}
        {activeSlide === 3 && <Slide3Challenges onNextSlide={handleNext} />}
        {activeSlide === 4 && (
          <Slide4Solution onOpenLiveDemo={onOpenLiveDemo} onNextSlide={handleNext} />
        )}
        {activeSlide === 5 && (
          <Slide5Features onOpenLiveDemo={onOpenLiveDemo} onNextSlide={handleNext} />
        )}
        {activeSlide === 6 && (
          <Slide6HowItWorks onOpenLiveDemo={onOpenLiveDemo} onNextSlide={handleNext} />
        )}
        {activeSlide === 7 && <Slide7Impact onNextSlide={handleNext} />}
        {activeSlide === 8 && (
          <Slide8Conclusion
            onOpenLiveDemo={onOpenLiveDemo}
            onResetToSlide1={() => setActiveSlide(1)}
          />
        )}
      </div>

      {/* Speaker Notes Drawer (Toggled) */}
      {showNotes && (
        <div className="mt-4 p-4 rounded-xl border border-stone-800 bg-stone-900/95 no-print animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-stone-800 pb-2 mb-2">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400">
              <FileText className="w-3.5 h-3.5" />
              <span>Speaker Notes · Slide {activeSlide}: {currentSlideData.title}</span>
            </div>
            <button
              onClick={() => setShowNotes(false)}
              className="text-xs text-stone-500 hover:text-stone-300 cursor-pointer"
            >
              Close
            </button>
          </div>
          <ul className="space-y-1.5 text-xs text-stone-300">
            {currentSlideData.speakerNotes.map((note, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-emerald-400 font-mono">›</span>
                <span>{note}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Slide Overview Grid Modal (Toggled) */}
      {showGrid && (
        <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-md flex items-center justify-center p-6 no-print">
          <div className="bg-stone-900 border border-stone-800 rounded-2xl p-6 max-w-5xl w-full max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="text-sm font-bold text-white font-display">
                Slide Navigator ({SLIDES_DATA.length} Slides)
              </div>
              <button
                onClick={() => setShowGrid(false)}
                className="text-xs text-stone-400 hover:text-white px-2 py-1 rounded bg-stone-800 cursor-pointer"
              >
                Close (ESC)
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {SLIDES_DATA.map((s) => (
                <button
                  key={s.number}
                  onClick={() => {
                    setActiveSlide(s.number);
                    setShowGrid(false);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    activeSlide === s.number
                      ? 'border-emerald-500 bg-stone-950 ring-1 ring-emerald-500/30'
                      : 'border-stone-800 bg-stone-950/40 hover:border-stone-700'
                  }`}
                >
                  <div className="text-[10px] font-mono font-bold text-emerald-400 mb-1">
                    SLIDE 0{s.number}
                  </div>
                  <div className="text-xs font-semibold text-white truncate">
                    {s.title}
                  </div>
                  <div className="text-[10px] text-stone-400 truncate mt-0.5">
                    {s.category}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Presenter Toolbar (Bottom Contract) */}
      <div className="mt-4 pt-3 border-t border-stone-800 flex flex-wrap items-center justify-between gap-4 no-print text-xs text-stone-400">
        {/* Left: Slide Progress Indicators */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            {SLIDES_DATA.map((s) => (
              <button
                key={s.number}
                onClick={() => setActiveSlide(s.number)}
                title={`Jump to Slide ${s.number}: ${s.title}`}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  activeSlide === s.number
                    ? 'w-7 bg-emerald-400'
                    : 'w-2 bg-stone-700 hover:bg-stone-500'
                }`}
              />
            ))}
          </div>
          <span className="font-mono text-stone-300 font-medium tabular-nums ml-1">
            Slide {activeSlide} of 8
          </span>
        </div>

        {/* Center: Pitch Timer */}
        <div className="flex items-center gap-2 bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800">
          <Clock className="w-3.5 h-3.5 text-stone-400" />
          <span className={`font-mono font-bold tabular-nums ${timerSeconds <= 30 ? 'text-rose-400 animate-pulse' : 'text-stone-200'}`}>
            {formatTimer(timerSeconds)}
          </span>
          <button
            onClick={() => setIsTimerRunning((prev) => !prev)}
            title={isTimerRunning ? 'Pause Pitch Timer' : 'Start Pitch Timer'}
            className="p-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            {isTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 text-emerald-400" />}
          </button>
          <button
            onClick={() => {
              setIsTimerRunning(false);
              setTimerSeconds(180);
            }}
            title="Reset 3-min Timer"
            className="p-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>

        {/* Right: Controls & Navigation */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNotes((prev) => !prev)}
            className={`px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              showNotes ? 'bg-stone-800 text-emerald-400 border-stone-700' : 'border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800'
            }`}
            title="Toggle Speaker Notes (N)"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Notes</span>
          </button>

          <button
            onClick={() => setShowGrid((prev) => !prev)}
            className="px-2.5 py-1.5 rounded-lg border border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800 text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5"
            title="Slide Grid Overview (G)"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Grid</span>
          </button>

          <button
            onClick={() => window.print()}
            className="px-2.5 py-1.5 rounded-lg border border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800 text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5"
            title="Export Presentation to PDF"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Print / PDF</span>
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg border border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800 transition-colors cursor-pointer"
            title="Toggle Fullscreen (F)"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          <div className="h-4 w-px bg-stone-800 mx-1" />

          {/* Previous & Next Buttons */}
          <button
            onClick={handlePrev}
            disabled={activeSlide <= 1}
            className="p-1.5 rounded-lg border border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800 disabled:opacity-40 transition-colors cursor-pointer"
            title="Previous Slide (Left Arrow)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={handleNext}
            disabled={activeSlide >= 8}
            className="p-1.5 rounded-lg border border-stone-800 bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-40 transition-colors cursor-pointer"
            title="Next Slide (Right Arrow)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
