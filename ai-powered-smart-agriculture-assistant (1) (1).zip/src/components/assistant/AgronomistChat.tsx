import React, { useState } from 'react';
import { FarmingAdvisorResponse } from '../../types';
import { Sparkles, Send, CheckCircle2, Lightbulb, Package, RefreshCw, Bot, User, MessageSquare } from 'lucide-react';

export const AgronomistChat: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [cropContext, setCropContext] = useState<string>('Tomato');
  const [loading, setLoading] = useState<boolean>(false);
  const [response, setResponse] = useState<FarmingAdvisorResponse | null>(null);
  const [engineUsed, setEngineUsed] = useState<string>('');

  const quickPrompts = [
    {
      label: 'Tomato Blight Triage',
      crop: 'Tomato',
      q: 'My tomato leaves have brown water-soaked spots with white fuzz after heavy rain. What immediate steps should I take?',
    },
    {
      label: 'Crop Rotation for Wheat',
      crop: 'Wheat / Cereal',
      q: 'What is the best legume crop rotation after harvesting wheat in sandy loam soil to restore nitrogen?',
    },
    {
      label: 'Organic Neem Bio-spray',
      crop: 'General Vegetables',
      q: 'How do I prepare an organic neem seed kernel extract (NSKE 5%) bio-pesticide to control chewing pests?',
    },
    {
      label: 'Maize Potassium Timing',
      crop: 'Maize / Corn',
      q: 'When is the exact phenological stage to top-dress potassium in maize to maximize cob filling?',
    },
  ];

  const handleSend = async (questionText?: string, cropName?: string) => {
    const qToSend = questionText || query;
    if (!qToSend.trim()) return;

    setLoading(true);
    try {
      const res = await fetch('/api/farming-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: qToSend,
          crop: cropName || cropContext,
          location: 'Smallholder Subtropical Ag Zone',
        }),
      });

      const data = await res.json();
      if (data.success && data.data) {
        setResponse(data.data);
        setEngineUsed(data.engine || 'Gemini 3.8 Flash');
      }
    } catch (err) {
      console.error('Advisor error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="p-4 rounded-xl border border-stone-800 bg-stone-900/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            <Bot className="w-4 h-4" />
            <span>Pillar 05 · Conversational Farm Advisory</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display">
            24/7 AI Agronomist & Farming Guidance
          </h3>
          <p className="text-xs text-stone-300 mt-0.5">
            Ask any question regarding crop symptoms, fertilizer timing, organic preparations, or harvest schedules.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800">
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Multilingual Agro-Reasoning Engine</span>
        </div>
      </div>

      {/* Quick Prompts */}
      <div>
        <div className="text-xs font-semibold uppercase tracking-wider text-stone-400 mb-2">
          Frequently Asked Farm Queries
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
          {quickPrompts.map((p) => (
            <button
              key={p.label}
              onClick={() => {
                setQuery(p.q);
                setCropContext(p.crop);
                handleSend(p.q, p.crop);
              }}
              className="p-3 rounded-xl border border-stone-800 bg-stone-950/60 hover:border-emerald-500/50 hover:bg-stone-950 text-left transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="text-xs font-semibold text-emerald-400 font-display">
                {p.label}
              </div>
              <p className="text-[11px] text-stone-400 line-clamp-2 mt-1 leading-snug">
                {p.q}
              </p>
              <div className="text-[10px] text-stone-500 mt-2 font-mono">
                Crop: {p.crop}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Query Input Box */}
      <div className="p-4 rounded-xl border border-stone-800 bg-stone-950/90 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <input
          type="text"
          value={cropContext}
          onChange={(e) => setCropContext(e.target.value)}
          placeholder="Crop name"
          className="w-full sm:w-40 px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 text-xs text-white placeholder-stone-600 focus:outline-hidden focus:border-emerald-500"
        />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSend();
          }}
          placeholder="Type your agricultural question here..."
          className="flex-1 px-3 py-2 rounded-lg bg-stone-900 border border-stone-800 text-xs text-white placeholder-stone-600 focus:outline-hidden focus:border-emerald-500"
        />
        <button
          onClick={() => handleSend()}
          disabled={loading || !query.trim()}
          className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
        >
          {loading ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Analyzing...</span>
            </>
          ) : (
            <>
              <Send className="w-3.5 h-3.5" />
              <span>Ask Agronomist</span>
            </>
          )}
        </button>
      </div>

      {/* AI Response Display */}
      {response ? (
        <div className="p-5 rounded-xl border border-emerald-950/80 bg-stone-950/95 space-y-4">
          <div className="flex items-center justify-between border-b border-stone-800 pb-3">
            <div className="flex items-center gap-2">
              <Bot className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400 font-mono">
                Agronomic Assessment · {engineUsed}
              </span>
            </div>
            <span className="text-[11px] text-stone-400 font-mono">
              Context: {cropContext}
            </span>
          </div>

          {/* Primary Answer Paragraph */}
          <div className="text-xs sm:text-sm text-stone-200 leading-relaxed bg-stone-900/60 p-4 rounded-xl border border-stone-800/80">
            {response.answer}
          </div>

          {/* Action Checklist */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-stone-300 mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Step-by-Step Field Action Plan
            </div>
            <div className="space-y-1.5">
              {response.actionChecklist.map((act, i) => (
                <div key={i} className="text-xs text-stone-300 flex items-start gap-2 bg-stone-900/40 p-2.5 rounded-lg border border-stone-800/60">
                  <span className="w-4 h-4 rounded-full bg-emerald-950 text-emerald-400 text-[10px] font-mono flex items-center justify-center font-bold shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <span>{act}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Pro-Tip & Resources Needed */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-lg bg-amber-950/20 border border-amber-900/60">
              <div className="text-[11px] font-bold text-amber-300 uppercase mb-1 flex items-center gap-1.5">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                <span>Pro-Agronomist High-Impact Tip</span>
              </div>
              <p className="text-xs text-stone-300 leading-relaxed">
                {response.expertTip}
              </p>
            </div>

            <div className="p-3.5 rounded-lg bg-stone-900/70 border border-stone-800">
              <div className="text-[11px] font-bold text-teal-300 uppercase mb-1 flex items-center gap-1.5">
                <Package className="w-3.5 h-3.5 text-teal-400" />
                <span>Required Field Materials</span>
              </div>
              <ul className="text-xs text-stone-300 space-y-1">
                {response.resourcesNeeded.map((res, idx) => (
                  <li key={idx} className="flex items-center gap-1.5">
                    <span className="text-emerald-400 font-mono text-[10px]">›</span>
                    <span>{res}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-10 rounded-xl border border-stone-800 bg-stone-950/60 text-center text-stone-400">
          <Bot className="w-8 h-8 text-stone-600 mx-auto mb-2" />
          <div className="text-sm font-semibold text-stone-300">Agricultural Knowledgebase Active</div>
          <div className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
            Choose a quick topic above or type your specific question to get immediate agronomist guidance.
          </div>
        </div>
      )}
    </div>
  );
};
