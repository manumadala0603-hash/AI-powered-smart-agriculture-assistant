import React, { useState } from 'react';
import { RecommendationResponse } from '../../types';
import { Sparkles, RefreshCw, CheckCircle2, Droplets, TrendingUp, Calendar, AlertCircle, Compass } from 'lucide-react';

export const CropRecommender: React.FC = () => {
  const [nitrogen, setNitrogen] = useState<number>(90);
  const [phosphorus, setPhosphorus] = useState<number>(42);
  const [potassium, setPotassium] = useState<number>(43);
  const [ph, setPh] = useState<number>(6.5);
  const [rainfall, setRainfall] = useState<number>(850);
  const [temperature, setTemperature] = useState<number>(26);
  const [season, setSeason] = useState<string>('Kharif / Monsoon');
  const [soilType, setSoilType] = useState<string>('Alluvial Loam');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<RecommendationResponse | null>(null);
  const [engineUsed, setEngineUsed] = useState<string>('');

  const presets = [
    {
      name: 'Semi-Arid Drylands',
      data: { n: 45, p: 25, k: 30, ph: 7.6, rain: 450, temp: 31, season: 'Kharif / Monsoon', soil: 'Sandy Loam' },
    },
    {
      name: 'High-Rainfall Alluvial',
      data: { n: 110, p: 55, k: 50, ph: 6.8, rain: 1450, temp: 28, season: 'Kharif / Monsoon', soil: 'Alluvial Loam' },
    },
    {
      name: 'Black Cotton Soil',
      data: { n: 80, p: 40, k: 65, ph: 7.8, rain: 720, temp: 29, season: 'Rabi / Winter', soil: 'Black Soil' },
    },
    {
      name: 'Acidic Hill Soil',
      data: { n: 60, p: 20, k: 35, ph: 5.5, rain: 1200, temp: 21, season: 'Spring / Autumn', soil: 'Red / Laterite' },
    },
  ];

  const applyPreset = (presetData: any) => {
    setNitrogen(presetData.n);
    setPhosphorus(presetData.p);
    setPotassium(presetData.k);
    setPh(presetData.ph);
    setRainfall(presetData.rain);
    setTemperature(presetData.temp);
    setSeason(presetData.season);
    setSoilType(presetData.soil);
    setResult(null);
  };

  const handleRecommend = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/crop-recommendation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nitrogen,
          phosphorus,
          potassium,
          ph,
          rainfall,
          temperature,
          season,
          soilType,
        }),
      });
      const data = await res.json();
      if (data.success && data.data) {
        setResult(data.data);
        setEngineUsed(data.engine || 'Gemini 3.8 Flash');
      }
    } catch (err) {
      console.error('Crop recommendation error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="p-4 rounded-xl border border-stone-800 bg-stone-900/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            <Compass className="w-4 h-4" />
            <span>Pillar 02 · Agro-Economic Optimization</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display">
            Multi-Objective Crop Recommendation Engine
          </h3>
          <p className="text-xs text-stone-300 mt-0.5">
            Evaluates soil chemistry, seasonal rainfall, and market economics to match optimal cultivars.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] text-stone-400 mr-1">Presets:</span>
          {presets.map((p) => (
            <button
              key={p.name}
              onClick={() => applyPreset(p.data)}
              className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-stone-950 border border-stone-800 hover:border-stone-700 text-stone-300 transition-colors cursor-pointer"
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Grid: Sliders & Controls on Left, Results on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Parameter Sliders */}
        <div className="lg:col-span-5 p-5 rounded-xl border border-stone-800 bg-stone-950/80 space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-stone-300 border-b border-stone-800 pb-2">
            Soil Chemistry & Climate Inputs
          </div>

          {/* Nitrogen Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 font-medium">Nitrogen (N)</span>
              <span className="font-mono text-emerald-400 font-semibold">{nitrogen} kg/ha</span>
            </div>
            <input
              type="range"
              min="10"
              max="200"
              value={nitrogen}
              onChange={(e) => setNitrogen(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Phosphorus Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 font-medium">Phosphorus (P)</span>
              <span className="font-mono text-teal-400 font-semibold">{phosphorus} kg/ha</span>
            </div>
            <input
              type="range"
              min="5"
              max="120"
              value={phosphorus}
              onChange={(e) => setPhosphorus(Number(e.target.value))}
              className="w-full accent-teal-500 cursor-pointer"
            />
          </div>

          {/* Potassium Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 font-medium">Potassium (K)</span>
              <span className="font-mono text-lime-400 font-semibold">{potassium} kg/ha</span>
            </div>
            <input
              type="range"
              min="10"
              max="150"
              value={potassium}
              onChange={(e) => setPotassium(Number(e.target.value))}
              className="w-full accent-lime-500 cursor-pointer"
            />
          </div>

          {/* Soil pH Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 font-medium">Soil pH Level</span>
              <span className="font-mono text-amber-400 font-semibold">{ph.toFixed(1)} pH</span>
            </div>
            <input
              type="range"
              min="4.5"
              max="9.0"
              step="0.1"
              value={ph}
              onChange={(e) => setPh(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Rainfall Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 font-medium">Annual Rainfall</span>
              <span className="font-mono text-sky-400 font-semibold">{rainfall} mm</span>
            </div>
            <input
              type="range"
              min="200"
              max="2500"
              step="50"
              value={rainfall}
              onChange={(e) => setRainfall(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          {/* Temperature Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 font-medium">Mean Temperature</span>
              <span className="font-mono text-rose-400 font-semibold">{temperature} °C</span>
            </div>
            <input
              type="range"
              min="12"
              max="42"
              value={temperature}
              onChange={(e) => setTemperature(Number(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
          </div>

          {/* Season & Soil Type Selectors */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="text-[11px] text-stone-400 block mb-1">Growing Season</label>
              <select
                value={season}
                onChange={(e) => setSeason(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-xs text-stone-200"
              >
                <option>Kharif / Monsoon</option>
                <option>Rabi / Winter</option>
                <option>Zaid / Summer</option>
                <option>Spring / Autumn</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] text-stone-400 block mb-1">Soil Classification</label>
              <select
                value={soilType}
                onChange={(e) => setSoilType(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-xs text-stone-200"
              >
                <option>Alluvial Loam</option>
                <option>Black Soil</option>
                <option>Red / Laterite</option>
                <option>Sandy Loam</option>
                <option>Clay Loam</option>
              </select>
            </div>
          </div>

          {/* Trigger Button */}
          <button
            onClick={handleRecommend}
            disabled={loading}
            className="w-full mt-3 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Optimizing Cultivars...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Calculate Optimal Crops</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Recommended Crops Cards */}
        <div className="lg:col-span-7 space-y-4">
          {result ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-stone-400 border-b border-stone-800 pb-2">
                <span className="text-emerald-400 font-semibold uppercase">
                  Top Recommended Cultivars · {engineUsed}
                </span>
                <span className="font-mono">Ranked by Agro-Economic Index</span>
              </div>

              {/* Recommended Crops List */}
              <div className="space-y-3">
                {result.recommendedCrops.map((c, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border border-stone-800 bg-stone-950/90 hover:border-emerald-500/50 transition-colors"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-700 text-emerald-300 font-mono text-xs flex items-center justify-center font-bold">
                          {idx + 1}
                        </span>
                        <h4 className="text-base font-bold text-white font-display">
                          {c.crop}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800">
                          {c.suitabilityScore}% Match
                        </span>
                        <span className="px-2 py-0.5 rounded text-[11px] bg-stone-900 text-stone-300 border border-stone-800">
                          {c.waterRequirement} Water
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs text-stone-300 my-2.5">
                      <div className="flex items-center gap-1.5 bg-stone-900/60 p-2 rounded-md">
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Expected Yield: <strong className="text-white font-mono">{c.expectedYield}</strong></span>
                      </div>
                      <div className="flex items-center gap-1.5 bg-stone-900/60 p-2 rounded-md">
                        <Calendar className="w-3.5 h-3.5 text-teal-400" />
                        <span>Maturity: <strong className="text-white font-mono">{c.growthDurationDays} Days</strong></span>
                      </div>
                    </div>

                    <p className="text-xs text-stone-400 leading-relaxed">
                      <span className="text-stone-300 font-medium">Market Outlook:</span> {c.marketOutlook}
                    </p>
                    <p className="text-xs text-stone-400 leading-relaxed mt-1">
                      <span className="text-amber-400/90 font-medium">Field Precaution:</span> {c.keyPrecautions}
                    </p>
                  </div>
                ))}
              </div>

              {/* Soil Health Diagnostic Notes */}
              <div className="p-4 rounded-xl border border-stone-800 bg-stone-900/50 space-y-2">
                <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Soil Health & Fertilizer Adjustment Advice</span>
                </div>
                <p className="text-xs text-stone-300 leading-relaxed">
                  {result.soilHealthNote}
                </p>
                <div className="text-xs text-amber-300/90 bg-stone-950 p-2.5 rounded-lg border border-stone-800">
                  <span className="font-semibold text-stone-200">Recommended Fertilizer Dosage: </span>
                  {result.fertilizerAdjustment}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 rounded-xl border border-stone-800 bg-stone-950/60 text-center text-stone-400">
              <Compass className="w-8 h-8 text-stone-600 mx-auto mb-2" />
              <div className="text-sm font-semibold text-stone-300">Awaiting Soil & Climate Execution</div>
              <div className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                Adjust sliders or pick a regional preset on the left, then click "Calculate Optimal Crops" to rank the highest yielding crops.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
