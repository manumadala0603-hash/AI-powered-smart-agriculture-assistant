import React, { useState } from 'react';
import { SAMPLE_CROP_CASES } from '../../data/sampleCrops';
import { DiseaseDiagnosis, SampleCropCase } from '../../types';
import { Upload, Sparkles, CheckCircle2, AlertTriangle, ShieldCheck, RefreshCw, Microscope, Leaf } from 'lucide-react';

export const DiseaseDetector: React.FC = () => {
  const [selectedSample, setSelectedSample] = useState<SampleCropCase>(SAMPLE_CROP_CASES[0]);
  const [customImage, setCustomImage] = useState<string | null>(null);
  const [customCropName, setCustomCropName] = useState<string>('Tomato');
  const [symptomsInput, setSymptomsInput] = useState<string>(SAMPLE_CROP_CASES[0].symptoms);
  const [loading, setLoading] = useState<boolean>(false);
  const [diagnosis, setDiagnosis] = useState<DiseaseDiagnosis | null>(null);
  const [engineUsed, setEngineUsed] = useState<string>('');

  const handleSelectSample = (sample: SampleCropCase) => {
    setSelectedSample(sample);
    setCustomImage(null);
    setCustomCropName(sample.cropName);
    setSymptomsInput(sample.symptoms);
    setDiagnosis(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setCustomImage(base64);
        setDiagnosis(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    setLoading(true);
    try {
      const payload: any = {
        cropName: customCropName,
        symptoms: symptomsInput,
      };

      if (customImage) {
        payload.base64Image = customImage;
      }

      const res = await fetch('/api/crop-disease', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success && data.data) {
        setDiagnosis(data.data);
        setEngineUsed(data.engine || 'Gemini 3.8 Flash');
      }
    } catch (err) {
      console.error('Diagnosis error:', err);
    } finally {
      setLoading(false);
    }
  };

  const displayImage = customImage || selectedSample.image;

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="p-4 rounded-xl border border-stone-800 bg-stone-900/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            <Microscope className="w-4 h-4" />
            <span>Pillar 01 · Computer Vision Pathology</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display">
            Instant Crop Disease Diagnostic Engine
          </h3>
          <p className="text-xs text-stone-300 mt-0.5">
            Select a verified field case or upload your own leaf photo for AI pathogen classification.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-stone-400 bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Multimodal Vision Ready</span>
        </div>
      </div>

      {/* Main Grid: Sample Selector & Inspection Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Sample Case Picker & Upload */}
        <div className="lg:col-span-5 space-y-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-stone-400 mb-2 block">
              1. Choose a Field Test Sample
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {SAMPLE_CROP_CASES.map((sample) => {
                const isSelected = !customImage && selectedSample.id === sample.id;
                return (
                  <button
                    key={sample.id}
                    onClick={() => handleSelectSample(sample)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'border-emerald-500 bg-stone-950 ring-1 ring-emerald-500/30'
                        : 'border-stone-800 bg-stone-900/50 hover:border-stone-700'
                    }`}
                  >
                    <div className="h-20 w-full rounded-lg overflow-hidden mb-2 bg-stone-950 relative">
                      <img
                        src={sample.image}
                        alt={sample.cropName}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-1 right-1 bg-stone-950/80 backdrop-blur-xs text-[10px] px-1.5 py-0.5 rounded text-emerald-300 font-mono">
                        {sample.cropName}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white font-display truncate">
                        {sample.diseaseLabel}
                      </div>
                      <div className="text-[10px] text-stone-400 truncate mt-0.5">
                        {sample.badge}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Or Custom Upload */}
          <div className="p-4 rounded-xl border border-dashed border-stone-700 bg-stone-950/60 text-center">
            <Upload className="w-5 h-5 text-stone-400 mx-auto mb-1.5" />
            <div className="text-xs font-medium text-stone-200">Or Upload Your Own Leaf Photo</div>
            <div className="text-[11px] text-stone-500 mt-0.5 mb-2.5">PNG, JPG or WebP up to 10MB</div>
            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer transition-colors">
              <span>Select Local File</span>
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          {/* Observed Symptoms Input */}
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-stone-400 mb-1.5 block">
              2. Crop Type & Farmer Observations
            </label>
            <div className="space-y-2">
              <input
                type="text"
                value={customCropName}
                onChange={(e) => setCustomCropName(e.target.value)}
                placeholder="Crop name (e.g., Tomato, Rice, Maize, Potato)"
                className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-800 text-xs text-white placeholder-stone-600 focus:outline-hidden focus:border-emerald-500"
              />
              <textarea
                value={symptomsInput}
                onChange={(e) => setSymptomsInput(e.target.value)}
                rows={2}
                placeholder="Describe visible spots, leaf curling, color..."
                className="w-full px-3 py-2 rounded-lg bg-stone-950 border border-stone-800 text-xs text-stone-300 placeholder-stone-600 focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Trigger Analysis Button */}
          <button
            onClick={handleAnalyze}
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Running Gemini Vision Inference...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Diagnose Pathogen Now</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Active Preview & Diagnosis Report */}
        <div className="lg:col-span-7 space-y-4">
          {/* Active Image Inspection Card */}
          <div className="p-4 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-semibold text-stone-300 flex items-center gap-1.5">
                <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                <span>Leaf Inspection Frame</span>
              </div>
              <span className="text-[11px] font-mono text-stone-400">
                Crop: {customCropName}
              </span>
            </div>

            <div className="relative h-64 sm:h-72 w-full rounded-xl overflow-hidden bg-stone-950 border border-stone-800">
              <img
                src={displayImage}
                alt="Inspected crop leaf"
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
              {/* Overlay target crosshair */}
              <div className="absolute inset-0 pointer-events-none border border-emerald-500/20 m-6 rounded-lg flex items-center justify-center">
                <div className="text-[10px] font-mono text-emerald-400 bg-stone-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                  Target Lesion Region Scanned
                </div>
              </div>
            </div>
          </div>

          {/* Diagnosis Result Card */}
          {diagnosis ? (
            <div className="p-5 rounded-xl border border-emerald-900/80 bg-stone-950/95 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-3">
                <div>
                  <div className="text-[11px] font-mono uppercase text-emerald-400">
                    DIAGNOSIS CONFIRMED · {engineUsed}
                  </div>
                  <h4 className="text-xl font-bold text-white font-display">
                    {diagnosis.diseaseName}
                  </h4>
                  <div className="text-xs italic text-stone-400">
                    Organism: {diagnosis.scientificName} · Pathogen: {diagnosis.pathogenType}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-[10px] text-stone-400 uppercase">Confidence</div>
                    <div className="text-lg font-mono font-bold text-emerald-400 tabular-nums">
                      {diagnosis.confidence}%
                    </div>
                  </div>
                  <div className="px-2.5 py-1 rounded-md bg-stone-900 border border-stone-800 text-xs font-semibold text-rose-400">
                    {diagnosis.severity} Severity
                  </div>
                </div>
              </div>

              {/* Advisory Summary */}
              <p className="text-xs text-stone-300 leading-relaxed bg-stone-900/60 p-3 rounded-lg border border-stone-800">
                {diagnosis.advisorySummary}
              </p>

              {/* Immediate Actions Checklist */}
              <div>
                <div className="text-xs font-semibold text-stone-200 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  Immediate Action Checklist (Next 24-48 Hours)
                </div>
                <div className="space-y-1.5">
                  {diagnosis.immediateActions.map((act, i) => (
                    <div key={i} className="text-xs text-stone-300 flex items-start gap-2 bg-stone-900/40 p-2 rounded-md">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{act}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dual Prescription: Organic & Chemical */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-900/60">
                  <div className="text-[11px] font-bold text-emerald-400 uppercase mb-1 flex items-center gap-1">
                    <span>🌱</span> Organic Bio-Control
                  </div>
                  <div className="text-xs text-stone-300 leading-relaxed">
                    {diagnosis.organicTreatment}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-stone-900/70 border border-stone-800">
                  <div className="text-[11px] font-bold text-teal-400 uppercase mb-1 flex items-center gap-1">
                    <span>🧪</span> Calibrated Chemical Spray
                  </div>
                  <div className="text-xs text-stone-300 leading-relaxed">
                    {diagnosis.chemicalTreatment}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 rounded-xl border border-stone-800 bg-stone-950/60 text-center text-stone-400">
              <Microscope className="w-8 h-8 text-stone-600 mx-auto mb-2" />
              <div className="text-sm font-semibold text-stone-300">Ready for Diagnosis</div>
              <div className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                Click "Diagnose Pathogen Now" to trigger multimodal neural classification and obtain precision organic & chemical prescriptions.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
