import React, { useState } from 'react';
import { DiseaseDetector } from './DiseaseDetector';
import { CropRecommender } from './CropRecommender';
import { WeatherAdvisory } from './WeatherAdvisory';
import { SoilAnalyzer } from './SoilAnalyzer';
import { AgronomistChat } from './AgronomistChat';
import { Microscope, Compass, CloudRain, FlaskConical, Bot, ArrowLeft } from 'lucide-react';

interface LiveAssistantViewProps {
  onBackToSlides: () => void;
}

export const LiveAssistantView: React.FC<LiveAssistantViewProps> = ({ onBackToSlides }) => {
  const [activeTab, setActiveTab] = useState<'disease' | 'recommend' | 'weather' | 'soil' | 'chat'>('disease');

  const tabs = [
    { id: 'disease', label: 'Disease Detection', icon: <Microscope className="w-4 h-4" /> },
    { id: 'recommend', label: 'Crop Recommendation', icon: <Compass className="w-4 h-4" /> },
    { id: 'weather', label: 'Weather Advisory', icon: <CloudRain className="w-4 h-4" /> },
    { id: 'soil', label: 'Soil Health & NPK', icon: <FlaskConical className="w-4 h-4" /> },
    { id: 'chat', label: 'Ask Agronomist AI', icon: <Bot className="w-4 h-4" /> },
  ] as const;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Bar Navigation back to Slide Deck */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToSlides}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-700 bg-stone-900 hover:bg-stone-800 text-stone-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Pitch Slides</span>
          </button>
          <div className="h-4 w-px bg-stone-800" />
          <div className="text-xs text-stone-400">
            <span className="text-emerald-400 font-semibold">Live Sandbox Prototype</span>
            <span className="mx-2">·</span>
            <span>AI-Powered Smart Agriculture Assistant</span>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-stone-900 border border-stone-800 overflow-x-auto max-w-full">
          {tabs.map((t) => {
            const isActive = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
                }`}
              >
                {t.icon}
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Module Workspace */}
      <div className="transition-all duration-200">
        {activeTab === 'disease' && <DiseaseDetector />}
        {activeTab === 'recommend' && <CropRecommender />}
        {activeTab === 'weather' && <WeatherAdvisory />}
        {activeTab === 'soil' && <SoilAnalyzer />}
        {activeTab === 'chat' && <AgronomistChat />}
      </div>
    </div>
  );
};
