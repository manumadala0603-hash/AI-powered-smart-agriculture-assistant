import React, { useState } from 'react';
import { FlaskConical, CheckCircle2, AlertTriangle, Sparkles, Scale, Info } from 'lucide-react';

export const SoilAnalyzer: React.FC = () => {
  const [nitrogenLevel, setNitrogenLevel] = useState<'Low' | 'Medium' | 'High'>('Low');
  const [phosphorusLevel, setPhosphorusLevel] = useState<'Low' | 'Medium' | 'High'>('Medium');
  const [potassiumLevel, setPotassiumLevel] = useState<'Low' | 'Medium' | 'High'>('High');
  const [phVal, setPhVal] = useState<number>(6.2);
  const [organicCarbon, setOrganicCarbon] = useState<number>(0.45);

  const getPhStatus = (ph: number) => {
    if (ph < 5.5) return { label: 'Strongly Acidic', color: 'text-rose-400', note: 'Severe Phosphorus, Calcium & Magnesium lockout; potential Aluminum toxicity.' };
    if (ph < 6.5) return { label: 'Slightly Acidic', color: 'text-emerald-400', note: 'Optimal range for most cereals, legumes, and solanaceous crops.' };
    if (ph <= 7.5) return { label: 'Neutral', color: 'text-emerald-400', note: 'Peak macronutrient bio-availability; thriving bacterial and earthworm biome.' };
    if (ph <= 8.5) return { label: 'Moderately Alkaline', color: 'text-amber-400', note: 'Iron, Zinc, Manganese, and Boron lockout causing leaf chlorosis.' };
    return { label: 'Strongly Alkaline / Sodic', color: 'text-rose-400', note: 'High sodium hazard; gypsum soil amendment and sulfur application required.' };
  };

  const phStatus = getPhStatus(phVal);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="p-4 rounded-xl border border-stone-800 bg-stone-900/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            <FlaskConical className="w-4 h-4" />
            <span>Pillar 04 · Soil Chemistry & Biological Health</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display">
            NPK Stoichiometry & Soil Health Diagnostics
          </h3>
          <p className="text-xs text-stone-300 mt-0.5">
            Interprets electrochemical soil lab indices into bio-fertilizer dosages and pH remediation protocols.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800">
          <Scale className="w-3.5 h-3.5" />
          <span>NPK Stoichiometric Balancer</span>
        </div>
      </div>

      {/* Interactive Controls & Soil Health Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Soil Nutrient Inputs */}
        <div className="lg:col-span-5 p-5 rounded-xl border border-stone-800 bg-stone-950/80 space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-stone-300 border-b border-stone-800 pb-2">
            Soil Test Parameters
          </div>

          {/* Nitrogen Status */}
          <div>
            <label className="text-xs text-stone-300 block mb-1.5">Available Nitrogen (N)</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Low', 'Medium', 'High'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setNitrogenLevel(lvl)}
                  className={`py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                    nitrogenLevel === lvl
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-600'
                      : 'bg-stone-900 text-stone-400 border-stone-800'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Phosphorus Status */}
          <div>
            <label className="text-xs text-stone-300 block mb-1.5">Available Phosphorus (P2O5)</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Low', 'Medium', 'High'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setPhosphorusLevel(lvl)}
                  className={`py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                    phosphorusLevel === lvl
                      ? 'bg-teal-950 text-teal-300 border-teal-600'
                      : 'bg-stone-900 text-stone-400 border-stone-800'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Potassium Status */}
          <div>
            <label className="text-xs text-stone-300 block mb-1.5">Available Potassium (K2O)</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Low', 'Medium', 'High'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setPotassiumLevel(lvl)}
                  className={`py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                    potassiumLevel === lvl
                      ? 'bg-lime-950 text-lime-300 border-lime-600'
                      : 'bg-stone-900 text-stone-400 border-stone-800'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Soil pH Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300">Soil pH Reaction</span>
              <span className={`font-mono font-bold ${phStatus.color}`}>{phVal.toFixed(1)} pH ({phStatus.label})</span>
            </div>
            <input
              type="range"
              min="4.5"
              max="9.0"
              step="0.1"
              value={phVal}
              onChange={(e) => setPhVal(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Soil Organic Carbon */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300">Organic Carbon (OC %)</span>
              <span className="font-mono text-stone-200 font-bold">{organicCarbon.toFixed(2)}%</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="1.5"
              step="0.05"
              value={organicCarbon}
              onChange={(e) => setOrganicCarbon(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="text-[10px] text-stone-400 mt-1">
              {organicCarbon < 0.5 ? 'Depleted humus (Low)' : organicCarbon < 0.75 ? 'Moderate OC level' : 'Rich organic carbon (High)'}
            </div>
          </div>
        </div>

        {/* Right Column: Recommendations & Soil Prescription */}
        <div className="lg:col-span-7 space-y-4">
          {/* pH Reaction Card */}
          <div className="p-4 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-semibold text-stone-300 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-emerald-400" />
                <span>pH Bio-Availability Assessment</span>
              </div>
              <span className={`text-xs font-mono font-bold ${phStatus.color}`}>
                {phStatus.label}
              </span>
            </div>
            <p className="text-xs text-stone-300 leading-relaxed">
              {phStatus.note}
            </p>
          </div>

          {/* Bio-fertilizer Inoculant Recommendations */}
          <div className="p-4 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Recommended Bio-Inoculants & Microbial Boosters</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="p-2.5 rounded-lg bg-stone-900/60 border border-stone-800">
                <div className="font-semibold text-stone-200">
                  {nitrogenLevel === 'Low' ? 'Azotobacter / Rhizobium Bio-fertilizer' : 'Maintenance Bio-Culture'}
                </div>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Fixes atmospheric nitrogen biologically, saving up to 25% of synthetic urea costs.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-stone-900/60 border border-stone-800">
                <div className="font-semibold text-stone-200">
                  PSB (Phosphate Solubilizing Bacteria)
                </div>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Secretes organic acids to unlock fixed insoluble phosphorus in soil mineral matrices.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-stone-900/60 border border-stone-800">
                <div className="font-semibold text-stone-200">
                  VAM (Mycorrhizal Bio-inoculant)
                </div>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Expands effective root surface area 10-fold, boosting water and zinc uptake during dry spells.
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-stone-900/60 border border-stone-800">
                <div className="font-semibold text-stone-200">
                  {organicCarbon < 0.5 ? 'Vermicompost + Green Manure' : 'Humic Acid Foliar Spray'}
                </div>
                <p className="text-[11px] text-stone-400 mt-0.5">
                  Increases cation-exchange capacity and restores native beneficial soil fungal populations.
                </p>
              </div>
            </div>
          </div>

          {/* Chemical Fertilizer Dosage Adjustment */}
          <div className="p-4 rounded-xl border border-stone-800 bg-stone-900/70">
            <div className="text-xs font-semibold text-stone-200 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Recommended Basal Application (Per Hectare)</span>
            </div>
            <div className="p-3 rounded-lg bg-stone-950 border border-stone-800 text-xs text-stone-300 font-mono leading-relaxed">
              Basal Urea: {nitrogenLevel === 'Low' ? '55 kg/ha' : nitrogenLevel === 'Medium' ? '35 kg/ha' : '20 kg/ha'} · Single Super Phosphate (SSP): {phosphorusLevel === 'Low' ? '60 kg/ha' : phosphorusLevel === 'Medium' ? '30 kg/ha' : '15 kg/ha'} · MOP: {potassiumLevel === 'Low' ? '40 kg/ha' : potassiumLevel === 'Medium' ? '25 kg/ha' : '10 kg/ha'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
