import React, { useState } from 'react';
import { CloudRain, Wind, Thermometer, Droplets, AlertTriangle, CheckCircle2, ShieldCheck, Sun, Clock } from 'lucide-react';

export const WeatherAdvisory: React.FC = () => {
  const [temperature, setTemperature] = useState<number>(27);
  const [humidity, setHumidity] = useState<number>(78);
  const [windSpeed, setWindSpeed] = useState<number>(9);
  const [rainProb, setRainProb] = useState<number>(25);
  const [targetCrop, setTargetCrop] = useState<string>('Tomato / Solanaceae');

  // Dynamic agronomic calculations
  const isSpraySafe = windSpeed <= 14 && rainProb <= 35 && humidity <= 82;
  const fungalRisk = humidity > 80 && temperature >= 18 && temperature <= 28;
  const evapoTranspirationLoss = ((temperature * 0.18 + (100 - humidity) * 0.05)).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="p-4 rounded-xl border border-stone-800 bg-stone-900/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            <CloudRain className="w-4 h-4" />
            <span>Pillar 03 · Microclimate & Weather Intelligence</span>
          </div>
          <h3 className="text-lg font-bold text-white font-display">
            Precision Spray Window & Microclimate Advisory
          </h3>
          <p className="text-xs text-stone-300 mt-0.5">
            Real-time computation of chemical spray safety windows, fungal sporulation alerts, and irrigation schedules.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-stone-950 px-3 py-1.5 rounded-lg border border-stone-800">
          <Clock className="w-3.5 h-3.5" />
          <span>72-Hour Microclimate Radar Sync</span>
        </div>
      </div>

      {/* Weather Controls & Microclimate Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Sliders for Weather simulation */}
        <div className="lg:col-span-5 p-5 rounded-xl border border-stone-800 bg-stone-950/80 space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-stone-300 border-b border-stone-800 pb-2">
            Simulate Current Farm Weather Telemetry
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 flex items-center gap-1.5">
                <Thermometer className="w-3.5 h-3.5 text-rose-400" /> Temperature
              </span>
              <span className="font-mono text-rose-400 font-semibold">{temperature} °C</span>
            </div>
            <input
              type="range"
              min="10"
              max="45"
              value={temperature}
              onChange={(e) => setTemperature(Number(e.target.value))}
              className="w-full accent-rose-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-sky-400" /> Relative Humidity
              </span>
              <span className="font-mono text-sky-400 font-semibold">{humidity}%</span>
            </div>
            <input
              type="range"
              min="20"
              max="98"
              value={humidity}
              onChange={(e) => setHumidity(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 flex items-center gap-1.5">
                <Wind className="w-3.5 h-3.5 text-teal-400" /> Wind Velocity
              </span>
              <span className="font-mono text-teal-400 font-semibold">{windSpeed} km/h</span>
            </div>
            <input
              type="range"
              min="0"
              max="35"
              value={windSpeed}
              onChange={(e) => setWindSpeed(Number(e.target.value))}
              className="w-full accent-teal-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-stone-300 flex items-center gap-1.5">
                <CloudRain className="w-3.5 h-3.5 text-indigo-400" /> 6-Hour Rain Probability
              </span>
              <span className="font-mono text-indigo-400 font-semibold">{rainProb}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={rainProb}
              onChange={(e) => setRainProb(Number(e.target.value))}
              className="w-full accent-indigo-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-[11px] text-stone-400 block mb-1">Target Crop Focus</label>
            <select
              value={targetCrop}
              onChange={(e) => setTargetCrop(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-xs text-stone-200"
            >
              <option>Tomato / Solanaceae</option>
              <option>Paddy Rice / Wetland</option>
              <option>Maize / Corn</option>
              <option>Wheat / Cereal</option>
              <option>Cotton / Cash Crop</option>
            </select>
          </div>
        </div>

        {/* Right Column: Calculated Advisories */}
        <div className="lg:col-span-7 space-y-4">
          {/* 1. Spray Window Card */}
          <div
            className={`p-5 rounded-xl border transition-all ${
              isSpraySafe
                ? 'border-emerald-700/80 bg-emerald-950/20'
                : 'border-rose-900/80 bg-rose-950/20'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-stone-300 flex items-center gap-1.5">
                {isSpraySafe ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                )}
                <span>Foliar Spray Window Status</span>
              </div>
              <span
                className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                  isSpraySafe ? 'bg-emerald-900/80 text-emerald-300' : 'bg-rose-900/80 text-rose-300'
                }`}
              >
                {isSpraySafe ? 'FAVORABLE TO SPRAY' : 'UNFAVORABLE / HALT SPRAY'}
              </span>
            </div>

            <p className="text-xs text-stone-200 leading-relaxed mt-1">
              {isSpraySafe
                ? `Current atmospheric conditions (Wind ${windSpeed} km/h, Rain probability ${rainProb}%) are optimal for foliar fungicide/insecticide application. Low chemical drift risk; maximum leaf stomatal absorption expected.`
                : `Avoid foliar application! ${
                    windSpeed > 14 ? `High wind (${windSpeed} km/h) causes >45% spray drift. ` : ''
                  }${
                    rainProb > 35 ? `High rain chance (${rainProb}%) will wash off active ingredients within hours. ` : ''
                  }${humidity > 82 ? `High humidity causes chemical droplet dripping.` : ''}`}
            </p>
          </div>

          {/* 2. Disease Outbreak Risk */}
          <div className="p-4 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-semibold text-stone-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>Microclimate Pathogen Sporulation Risk</span>
              </div>
              <span
                className={`text-xs font-mono font-bold ${
                  fungalRisk ? 'text-rose-400' : 'text-emerald-400'
                }`}
              >
                {fungalRisk ? 'HIGH FUNGAL RISK' : 'LOW RISK'}
              </span>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed">
              {fungalRisk
                ? `Ambient humidity of ${humidity}% combined with ${temperature}°C creates ideal incubation for late blight, downy mildew, and blast spores. Conduct field scouting immediately at sunrise.`
                : `Low relative humidity and stable thermal levels indicate suppressed fungal germination. Maintain routine preventive monitoring.`}
            </p>
          </div>

          {/* 3. Irrigation Schedule */}
          <div className="p-4 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-semibold text-stone-300 flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-sky-400" />
                <span>Evapotranspiration & Irrigation Guidance</span>
              </div>
              <span className="text-xs font-mono text-sky-400">
                Loss Rate: {evapoTranspirationLoss} mm/day
              </span>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed">
              {rainProb > 50
                ? `Postpone irrigation cycles. Incoming precipitation forecast is sufficient to maintain root zone moisture tension without wasting pumped electricity.`
                : `Schedule drip irrigation for early morning (05:30 - 08:00 AM) to minimize midday vapor loss (${evapoTranspirationLoss} mm/day) and prevent root crown cooling shock.`}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
