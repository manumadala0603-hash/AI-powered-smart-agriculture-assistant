import React from 'react';
import { Sparkles, ArrowRight, CheckCircle2, ShieldCheck, Cpu, Sprout } from 'lucide-react';

interface SlideProps {
  onOpenLiveDemo: () => void;
  onNextSlide: () => void;
}

export const Slide1Title: React.FC<SlideProps> = ({ onOpenLiveDemo, onNextSlide }) => {
  return (
    <div className="relative min-h-[640px] h-full flex flex-col justify-between overflow-hidden rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Background Hero with measured contrast scrim */}
      <div className="absolute inset-0 z-0 opacity-25 overflow-hidden">
        <img
          src="/src/assets/images/hero_smart_agriculture_1791353087287.jpg"
          alt="Sustainable precision agriculture fields"
          className="w-full h-full object-cover object-center filter saturate-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/80 to-stone-950/40" />
      </div>

      {/* Slide Top Bar Metadata (Clean unboxed text) */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 border-b border-stone-800/80 pb-5">
        <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
          <span className="text-emerald-400 font-semibold">Hackathon Submission</span>
          <span aria-hidden="true">·</span>
          <span>AI for Sustainable Agriculture</span>
          <span aria-hidden="true">·</span>
          <span>Slide 01 of 08</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-stone-400 font-mono tabular-nums">
          <span>Target: 500M+ Smallholder Farmers</span>
          <span aria-hidden="true">·</span>
          <span className="text-emerald-400">Gemini 3.8 Flash Vision</span>
        </div>
      </div>

      {/* Main Hero Proposition */}
      <div className="relative z-10 my-auto py-8 max-w-4xl">
        <div className="text-xs tracking-wider uppercase text-emerald-400 font-medium mb-3">
          Hackathon Problem Statement & Proposed Solution
        </div>
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white text-balance leading-tight font-display">
          AI-Powered Smart <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-lime-300">
            Agriculture Assistant
          </span>
        </h1>
        <p className="mt-5 text-base sm:text-lg text-stone-300 leading-relaxed max-w-2xl text-balance">
          A multimodal agronomy intelligence system analyzing crop imagery, live weather forecasts, soil chemical indices, and farm management data to deliver timely, hyper-localized farming decisions for smallholder growers.
        </p>

        {/* 4 Inputs to 1 Output Banner */}
        <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl">
          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/70">
            <div className="text-xs text-stone-400 mb-1">Input 01</div>
            <div className="text-sm font-semibold text-stone-200 flex items-center gap-1.5">
              <span className="text-emerald-400">🌱</span> Crop Images
            </div>
          </div>
          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/70">
            <div className="text-xs text-stone-400 mb-1">Input 02</div>
            <div className="text-sm font-semibold text-stone-200 flex items-center gap-1.5">
              <span className="text-teal-400">🌦️</span> Weather Data
            </div>
          </div>
          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/70">
            <div className="text-xs text-stone-400 mb-1">Input 03</div>
            <div className="text-sm font-semibold text-stone-200 flex items-center gap-1.5">
              <span className="text-lime-400">🧪</span> Soil Conditions
            </div>
          </div>
          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/70">
            <div className="text-xs text-stone-400 mb-1">Input 04</div>
            <div className="text-sm font-semibold text-stone-200 flex items-center gap-1.5">
              <span className="text-amber-400">🚜</span> Farming Data
            </div>
          </div>
        </div>

        {/* Call to Actions */}
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <button
            onClick={onOpenLiveDemo}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-colors cursor-pointer whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4" />
            <span>Launch Live Assistant Demo</span>
          </button>

          <button
            onClick={onNextSlide}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-lg border border-stone-700 bg-stone-800/80 hover:bg-stone-800 text-stone-200 transition-colors cursor-pointer whitespace-nowrap"
          >
            <span>Proceed to Problem Statement</span>
            <ArrowRight className="w-4 h-4 text-stone-400" />
          </button>
        </div>
      </div>

      {/* Footer Credentials */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 border-t border-stone-800/80 pt-4 text-xs text-stone-400">
        <div className="flex items-center gap-2">
          <span>Multimodal Agronomy Engine</span>
          <span aria-hidden="true">·</span>
          <span>Zero-Latency Offline Fallback</span>
          <span aria-hidden="true">·</span>
          <span>Multilingual Voice Ready</span>
        </div>
        <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
          <ShieldCheck className="w-4 h-4" />
          <span>Scientifically Validated Agronomic Protocols</span>
        </div>
      </div>
    </div>
  );
};
