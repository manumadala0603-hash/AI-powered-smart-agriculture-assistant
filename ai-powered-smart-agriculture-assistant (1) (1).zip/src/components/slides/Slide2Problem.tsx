import React, { useState } from 'react';
import { AlertTriangle, Users, Bug, DollarSign, ArrowRight, ShieldAlert } from 'lucide-react';

interface SlideProps {
  onNextSlide: () => void;
}

export const Slide2Problem: React.FC<SlideProps> = ({ onNextSlide }) => {
  const [selectedIssue, setSelectedIssue] = useState<number>(0);

  const issues = [
    {
      id: 0,
      title: 'Identifying Crop Diseases',
      stat: '40% Annual Yield Loss',
      icon: '🦠',
      difficulty: 'Early symptoms mimic simple nutrient hunger or drought stress, resulting in delayed or completely incorrect pesticide intervention.',
      consequences: [
        'Pathogens spread across adjacent acreage before visible necrosis appears.',
        'Over 70% of initial treatments misidentify fungal vs bacterial blights.',
        'Wasted input costs on ineffective broad-spectrum sprays that destroy beneficial predators.',
      ],
      impactMetric: 'Up to $220B in global agricultural crop destruction annually (FAO).',
    },
    {
      id: 1,
      title: 'Selecting Suitable Crops',
      stat: '60% Repeat Wrong Crop',
      icon: '🌾',
      difficulty: 'Farmers plant based on generational precedent rather than evolving soil chemical state, groundwater depletion, or seasonal rain forecasts.',
      consequences: [
        'Planting water-intensive crops in dropping water tables triggers mid-season crop failure.',
        'Mismatched soil pH induces nutrient lockout regardless of how much fertilizer is dumped.',
        'Severe vulnerability to market price crashes due to localized crop monoculture.',
      ],
      impactMetric: '25-35% lower profit margins compared to scientifically matched soil-crop pairings.',
    },
    {
      id: 2,
      title: 'Determining Farming Practices',
      stat: '30-45% Fertilizer Wasted',
      icon: '🚜',
      difficulty: 'Lack of precision tools forces farmers into guesswork: incorrect fertilizer ratios, wrong spray timing, and inefficient flood irrigation.',
      consequences: [
        'Excess nitrogen runoff causes soil acidification and hazardous groundwater leaching.',
        'Pesticide application during high winds or rain leads to 50%+ chemical drift wastage.',
        'Flood irrigation suffocates root aeration and accelerates root rot diseases.',
      ],
      impactMetric: 'Over 30% of smallholder operational capital is spent on misapplied farm inputs.',
    },
    {
      id: 3,
      title: 'Limited Agricultural Expert Access',
      stat: '1 : 11,000 Expert Ratio',
      icon: '👨‍🌾',
      difficulty: 'Public extension officers are overwhelmed and geographically distant; physical laboratory soil tests require 2 to 4 weeks turnaround.',
      consequences: [
        'Remote rural farmers must travel full days to township pesticide retail shops for advice.',
        'Shops frequently push high-margin non-essential chemicals over appropriate remedies.',
        'By the time test results arrive, active sporulation has permanently destroyed crop yield.',
      ],
      impactMetric: 'Over 85% of rural farmers have zero real-time access to certified agronomists.',
    },
  ];

  return (
    <div className="min-h-[640px] h-full flex flex-col justify-between rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
            <span className="text-emerald-400 font-semibold">Slide 02</span>
            <span aria-hidden="true">·</span>
            <span>Problem Discovery</span>
            <span aria-hidden="true">·</span>
            <span>The Smallholder Dilemma</span>
          </div>
          <div className="text-xs text-rose-400/90 font-mono flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>High Systemic Vulnerability</span>
          </div>
        </div>

        <div className="max-w-3xl">
          <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display">
            The Problem: Acute Information Asymmetry on the Ground
          </h2>
          <p className="mt-3 text-stone-300 text-sm sm:text-base leading-relaxed">
            Smallholder farmers make dozens of critical, irreversible agronomic decisions each season without real-time data or expert guidance.
          </p>
        </div>
      </div>

      {/* Interactive 4-Column Issue Cards */}
      <div className="my-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        {issues.map((issue, idx) => {
          const isSelected = selectedIssue === idx;
          return (
            <button
              key={issue.id}
              onClick={() => setSelectedIssue(idx)}
              className={`text-left p-5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'border-emerald-500/80 bg-stone-950 shadow-md ring-1 ring-emerald-500/30'
                  : 'border-stone-800 bg-stone-950/40 hover:border-stone-700 hover:bg-stone-950/70'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl">{issue.icon}</span>
                  <span className="text-xs font-mono font-semibold text-rose-400 tabular-nums">
                    {issue.stat}
                  </span>
                </div>
                <h3 className="text-base font-semibold text-stone-100 font-display">
                  {issue.title}
                </h3>
                <p className="mt-2 text-xs text-stone-400 line-clamp-3 leading-relaxed">
                  {issue.difficulty}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-800/80 flex items-center justify-between text-xs">
                <span className={isSelected ? 'text-emerald-400 font-medium' : 'text-stone-500'}>
                  {isSelected ? 'Active Focus' : 'Inspect Details'}
                </span>
                <span className="text-stone-600 font-mono text-[11px]">0{idx + 1}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Issue Deep Dive Detail Panel */}
      <div className="p-5 rounded-xl border border-stone-800 bg-stone-950/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex-1">
          <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            Root Cause & Field Friction Analysis · {issues[selectedIssue].title}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
            {issues[selectedIssue].consequences.map((c, i) => (
              <div key={i} className="text-xs text-stone-300 flex items-start gap-2 bg-stone-900/60 p-2.5 rounded-lg border border-stone-800/70">
                <span className="text-emerald-400 font-mono shrink-0">·</span>
                <span>{c}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="w-full md:w-72 shrink-0 p-3.5 rounded-lg border border-rose-950/60 bg-rose-950/20">
          <div className="text-[11px] font-semibold text-rose-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
            Quantified Field Loss
          </div>
          <div className="text-xs font-medium text-stone-200 leading-snug">
            {issues[selectedIssue].impactMetric}
          </div>
        </div>
      </div>

      {/* Slide Footer */}
      <div className="mt-6 pt-4 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
        <div>
          <span>Core Bottleneck: Zero-Latency Diagnostic Gap</span>
          <span className="mx-2">·</span>
          <span>Solution Prerequisite: Multimodal Synthesis</span>
        </div>
        <button
          onClick={onNextSlide}
          className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-medium transition-colors cursor-pointer"
        >
          <span>Next: Existing Challenges</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
