import React from 'react';
import { ArrowRight, CloudRain, Microscope, Trees, FlaskConical, Stethoscope } from 'lucide-react';

interface SlideProps {
  onNextSlide: () => void;
}

export const Slide3Challenges: React.FC<SlideProps> = ({ onNextSlide }) => {
  const challenges = [
    {
      num: '01',
      title: 'Disease Identification',
      icon: <Microscope className="w-5 h-5 text-emerald-400" />,
      tag: 'Pathology Barrier',
      description: 'Visual ambiguity between early fungal, bacterial, and nutrient deficiencies leads to fatal diagnostic delays.',
      points: [
        'Late blight spores travel airborne up to 20 miles in 48 hours.',
        'Farmers rely on township chemical stores who sell generic broad-spectrum sprays.',
        'Over 60% of crop damage is irreversible once visual leaf necrosis spreads.',
      ],
    },
    {
      num: '02',
      title: 'Crop Selection',
      icon: <Trees className="w-5 h-5 text-teal-400" />,
      tag: 'Agronomic Planning',
      description: 'Historical habits override scientific suitability, ignoring changing aquifer levels and regional market saturation.',
      points: [
        'Monocropping depletes specific soil strata year after year.',
        'Farmers plant water-heavy crops during declared meteorological drought cycles.',
        'Glut-induced price crashes force distress selling below production costs.',
      ],
    },
    {
      num: '03',
      title: 'Weather Uncertainty',
      icon: <CloudRain className="w-5 h-5 text-sky-400" />,
      tag: 'Climate Volatility',
      description: 'Erratic rain patterns, unseasonal frost, and sudden relative humidity spikes make traditional weather wisdom obsolete.',
      points: [
        'High humidity (>85%) combined with warm nights triggers explosive fungal sporulation.',
        'Spraying fungicides immediately prior to sudden rain washes away 90% of chemical investment.',
        'Unpredictable heatwaves at flowering stage abort pollination and destroy grain filling.',
      ],
    },
    {
      num: '04',
      title: 'Soil Suitability',
      icon: <FlaskConical className="w-5 h-5 text-lime-400" />,
      tag: 'Chemical Degradation',
      description: 'Invisible imbalances in soil pH and N-P-K ratios cause complete nutrient lockout despite heavy fertilizer applications.',
      points: [
        'Acidic soils (pH < 6.0) lock up Phosphorus, starving root development.',
        'Routine blanket Urea applications burn soil microbial biomes and exhaust humus.',
        'Soil testing laboratories require weeks to return physical sample analyses.',
      ],
    },
    {
      num: '05',
      title: 'Limited Expert Support',
      icon: <Stethoscope className="w-5 h-5 text-amber-400" />,
      tag: 'Extension Deficit',
      description: 'Severe geographic and staffing deficit of certified agronomists leaves rural growers without timely triage.',
      points: [
        'Average farmer must travel 25+ kilometers to reach an agricultural office.',
        'Government radio/TV advisories are regionally broad and ignore local field microclimates.',
        'Private consulting services are economically inaccessible to smallholder budgets.',
      ],
    },
  ];

  return (
    <div className="min-h-[640px] h-full flex flex-col justify-between rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
            <span className="text-emerald-400 font-semibold">Slide 03</span>
            <span aria-hidden="true">·</span>
            <span>Existing Challenges</span>
            <span aria-hidden="true">·</span>
            <span>Five Structural Bottlenecks</span>
          </div>
          <div className="text-xs text-stone-400 font-mono">
            <span>Critical Failure Vectors Identified</span>
          </div>
        </div>

        <div className="max-w-3xl">
          <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display">
            Existing Challenges in Current Farm Operations
          </h2>
          <p className="mt-3 text-stone-300 text-sm sm:text-base leading-relaxed">
            The confluence of five structural failure points prevents smallholder agriculture from achieving sustainable yields and profitability.
          </p>
        </div>
      </div>

      {/* 5 Distinct Challenge Cards */}
      <div className="my-6 grid grid-cols-1 md:grid-cols-5 gap-3.5">
        {challenges.map((c) => (
          <div
            key={c.num}
            className="p-4 rounded-xl border border-stone-800 bg-stone-950/70 flex flex-col justify-between hover:border-stone-700 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 rounded-lg bg-stone-900 border border-stone-800">
                  {c.icon}
                </div>
                <span className="text-xs font-mono text-stone-500 font-bold">{c.num}</span>
              </div>

              <div className="text-[11px] font-semibold uppercase tracking-wider text-stone-400 mb-1">
                {c.tag}
              </div>
              <h3 className="text-sm font-bold text-stone-100 font-display">
                {c.title}
              </h3>
              <p className="mt-2 text-xs text-stone-400 leading-relaxed">
                {c.description}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-stone-800/80 space-y-1.5">
              {c.points.map((p, idx) => (
                <div key={idx} className="text-[11px] text-stone-300 leading-tight flex items-start gap-1.5">
                  <span className="text-emerald-400 font-mono shrink-0">›</span>
                  <span>{p}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Takeaway */}
      <div className="pt-4 border-t border-stone-800 flex flex-wrap items-center justify-between gap-4 text-xs text-stone-400">
        <div className="flex items-center gap-2">
          <span className="text-stone-300 font-medium">Core Synthesis:</span>
          <span>Treating any single challenge in isolation fails; true solution requires multimodal data synthesis.</span>
        </div>
        <button
          onClick={onNextSlide}
          className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-medium transition-colors cursor-pointer"
        >
          <span>Next: Our AI Solution Architecture</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
