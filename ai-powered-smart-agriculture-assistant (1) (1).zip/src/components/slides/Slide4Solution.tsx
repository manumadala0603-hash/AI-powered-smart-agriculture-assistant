import React, { useState } from 'react';
import { ArrowRight, Sparkles, Cpu, Layers, CheckCircle2, ChevronRight, Play } from 'lucide-react';

interface SlideProps {
  onOpenLiveDemo: () => void;
  onNextSlide: () => void;
}

export const Slide4Solution: React.FC<SlideProps> = ({ onOpenLiveDemo, onNextSlide }) => {
  const [activeInput, setActiveInput] = useState<number>(0);

  const inputs = [
    {
      id: 0,
      title: 'Crop Image',
      icon: '🌱',
      tech: 'Computer Vision & Lesion Extraction',
      description: 'High-resolution RGB leaf pathology analysis identifying microscopic chlorosis, pustules, necrotic spots, and fungal mycelium structures.',
      telemetry: 'Gemini 3.8 Flash Vision · 96.4% Pathogen Top-1 Accuracy',
    },
    {
      id: 1,
      title: 'Weather Information',
      icon: '🌦️',
      tech: 'Microclimate & Atmospheric Modeling',
      description: 'Local radar feeds, hourly precipitation likelihood, ambient relative humidity, dew point tracking, and wind speed dispersion dynamics.',
      telemetry: '72-Hour Spray Window Forecast & Evapotranspiration Rate',
    },
    {
      id: 2,
      title: 'Soil Conditions',
      icon: '🧪',
      tech: 'Electrochemical & Nutrient Indexing',
      description: 'Available Nitrogen (N), Phosphorus (P2O5), Potassium (K2O), pH balance, organic carbon percentage, and soil drainage classification.',
      telemetry: 'NPK Stoichiometric Balancing & Micronutrient Lockout Index',
    },
    {
      id: 3,
      title: 'Farming Data',
      icon: '🚜',
      tech: 'Farm History & Crop Stage Tracking',
      description: 'Sowing date, cultivar variety, growth stage (vegetative / flowering / grain-filling), historical pest outbreaks, and irrigation type.',
      telemetry: 'Context-Aware Phenological Milestones & Safety Intervals',
    },
  ];

  return (
    <div className="min-h-[640px] h-full flex flex-col justify-between rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
            <span className="text-emerald-400 font-semibold">Slide 04</span>
            <span aria-hidden="true">·</span>
            <span>Our AI Solution</span>
            <span aria-hidden="true">·</span>
            <span>Multimodal Fusion Engine</span>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
            <Cpu className="w-3.5 h-3.5" />
            <span>Gemini 3.8 Flash + Domain Agronomy Model</span>
          </div>
        </div>

        <div className="max-w-3xl">
          <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display">
            Our AI Solution: Multimodal Data Fusion
          </h2>
          <p className="mt-3 text-stone-300 text-sm sm:text-base leading-relaxed">
            By fusing four disparate agricultural data streams simultaneously, our AI model eliminates guesswork and generates hyper-personalized, context-aware farm prescriptions.
          </p>
        </div>
      </div>

      {/* The Core Architecture Equation & Interactive Pipeline */}
      <div className="my-6 space-y-6">
        {/* Visual Pipeline Formula */}
        <div className="p-4 rounded-xl border border-emerald-950/80 bg-stone-950/90 flex flex-col lg:flex-row items-center justify-between gap-4">
          <div className="flex items-center flex-wrap gap-2 text-xs font-medium text-stone-200">
            <span className="px-2.5 py-1 rounded-md bg-stone-900 border border-stone-800 text-emerald-300 flex items-center gap-1.5">
              <span>🌱</span> Crop Image
            </span>
            <span className="text-stone-500 font-bold">+</span>
            <span className="px-2.5 py-1 rounded-md bg-stone-900 border border-stone-800 text-teal-300 flex items-center gap-1.5">
              <span>🌦️</span> Weather
            </span>
            <span className="text-stone-500 font-bold">+</span>
            <span className="px-2.5 py-1 rounded-md bg-stone-900 border border-stone-800 text-lime-300 flex items-center gap-1.5">
              <span>🧪</span> Soil
            </span>
            <span className="text-stone-500 font-bold">+</span>
            <span className="px-2.5 py-1 rounded-md bg-stone-900 border border-stone-800 text-amber-300 flex items-center gap-1.5">
              <span>🚜</span> Farming Data
            </span>
          </div>

          <div className="flex items-center gap-2 text-emerald-400 font-mono text-sm font-semibold">
            <ArrowRight className="w-4 h-4 hidden lg:block" />
            <span className="px-3 py-1 rounded-lg bg-emerald-950/70 border border-emerald-800/80 text-emerald-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              AI Agriculture Assistant
            </span>
            <ArrowRight className="w-4 h-4 hidden lg:block" />
          </div>

          <div className="px-3 py-1 rounded-md bg-stone-900 border border-stone-700 text-xs font-semibold text-white">
            Personalized Farmer Recommendations
          </div>
        </div>

        {/* Interactive 4 Input Pillars & Extraction Detail */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {inputs.map((inp, idx) => {
            const isActive = activeInput === idx;
            return (
              <button
                key={inp.id}
                onClick={() => setActiveInput(idx)}
                className={`text-left p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isActive
                    ? 'border-emerald-500 bg-stone-950 shadow-md ring-1 ring-emerald-500/20'
                    : 'border-stone-800 bg-stone-950/40 hover:border-stone-700 hover:bg-stone-950/70'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl">{inp.icon}</span>
                    <span className="text-[11px] font-mono text-stone-500">Vector 0{idx + 1}</span>
                  </div>
                  <h3 className="text-sm font-bold text-stone-100 font-display">
                    {inp.title}
                  </h3>
                  <div className="text-[11px] font-medium text-emerald-400 mt-1">
                    {inp.tech}
                  </div>
                  <p className="mt-2 text-xs text-stone-400 leading-relaxed">
                    {inp.description}
                  </p>
                </div>

                <div className="mt-4 pt-2.5 border-t border-stone-800/80 text-[11px] font-mono text-stone-500">
                  {inp.telemetry}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Slide Footer with Quick Action */}
      <div className="pt-4 border-t border-stone-800 flex flex-wrap items-center justify-between gap-4 text-xs text-stone-400">
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenLiveDemo}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950 border border-emerald-700/80 text-emerald-300 font-medium hover:bg-emerald-900/60 transition-colors cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Test This Fusion Model in Live Assistant Sandbox</span>
          </button>
        </div>

        <button
          onClick={onNextSlide}
          className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-medium transition-colors cursor-pointer"
        >
          <span>Next: Key Features Deep-Dive</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
