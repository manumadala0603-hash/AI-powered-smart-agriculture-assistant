import React, { useState } from 'react';
import { ArrowRight, Sparkles, CheckCircle2, ShieldCheck, Play } from 'lucide-react';

interface SlideProps {
  onOpenLiveDemo: () => void;
  onNextSlide: () => void;
}

export const Slide5Features: React.FC<SlideProps> = ({ onOpenLiveDemo, onNextSlide }) => {
  const [selectedFeature, setSelectedFeature] = useState<number>(0);

  const features = [
    {
      id: 0,
      title: 'Disease Detection',
      icon: '🌿',
      tagline: 'Computer Vision Pathology & Triage',
      badge: '96.4% Top-1 Accuracy',
      description: 'Instant leaf pathology diagnosis from smartphone photos. Identifies causal fungal, bacterial, viral, or deficiency agents.',
      capabilities: [
        'Precise lesion segmentation identifying pathogen genus and species.',
        'Calculates severity score (Low / Moderate / Severe) and transmission risk.',
        'Dual prescription: organic biological controls + calibrated chemical fungicides with pre-harvest safety intervals.',
        'Immediate quarantine and canopy hygiene protocols to halt field spread.',
      ],
      sampleOutput: 'Detected: Tomato Late Blight (Phytophthora infestans) · Confidence 96% · Action: Apply Mancozeb 75% WP @ 2.5g/L + Prune affected lower canopy.',
    },
    {
      id: 1,
      title: 'Crop Recommendation',
      icon: '🌾',
      tagline: 'Multi-Objective Agro-Economic Optimizer',
      badge: 'NPK & Climate Matching',
      description: 'Recommends highest-yield, highest-profit crops matching the farmer’s soil chemistry, rainfall, and regional seasonality.',
      capabilities: [
        'Analyzes soil Nitrogen, Phosphorus, Potassium, and pH balance.',
        'Projects expected yield in Tonnes / Hectare and days to harvest maturity.',
        'Evaluates water efficiency rating (Low, Moderate, High) against aquifer constraints.',
        'Provides market economic outlook to protect farmers against price crashes.',
      ],
      sampleOutput: 'Optimal Pairing: Yellow Hybrid Maize (94% Suitability) · Projected Yield: 5.8 T/Ha · Maturation: 105 Days · Strong feed industry demand.',
    },
    {
      id: 2,
      title: 'Weather-Based Advice',
      icon: '🌦️',
      tagline: 'Hyperlocal Microclimate Spray & Irrigation Advisor',
      badge: '72-Hour Precision Window',
      description: 'Prevents wasted chemical sprays and over-irrigation by computing safe microclimate operational windows.',
      capabilities: [
        'Calculates Spray Window: flags wind drift (>15 km/h) and rain wash-off threats.',
        'Disease Risk Index: monitors relative humidity (>85%) + temperature sweet-spots for fungal outbreaks.',
        'Evapotranspiration-based irrigation scheduling preventing waterlogging and root rot.',
        'Frost and extreme heat alerts with protective mitigation steps.',
      ],
      sampleOutput: 'Spray Advisory: Optimal spraying window tomorrow 06:30 - 09:00 AM (Wind 6 km/h, Humidity 68%). Halt evening spraying due to 70% rain probability.',
    },
    {
      id: 3,
      title: 'Soil Analysis',
      icon: '🧪',
      tagline: 'Soil Health & Chemical Stoichiometry Diagnostics',
      badge: 'Deficiency & pH Calibration',
      description: 'Translates soil test reports into plain-language nutrient balancing formulas and bio-fertilizer schedules.',
      capabilities: [
        'Evaluates available Nitrogen, Phosphorus, Potassium, and Organic Carbon.',
        'Detects soil pH acidity/alkalinity and flags specific micronutrient lockouts.',
        'Calculates exact corrective fertilizer dosages (Urea, DAP, SSP, MOP).',
        'Recommends biological soil conditioners (Rhizobium, Trichoderma, Mycorrhiza).',
      ],
      sampleOutput: 'Diagnostic: Soil pH 6.4 (Slightly Acidic). Moderate P deficiency detected. Recommend 25 kg/ha basal P2O5 via Single Super Phosphate + Azotobacter.',
    },
    {
      id: 4,
      title: 'Personalized Guidance',
      icon: '👨‍🌾',
      tagline: 'Conversational 24/7 AI Agronomist in Rural Dialects',
      badge: 'Multilingual Voice & Text',
      description: 'Empathetic agricultural advisor answering farmer questions with step-by-step verified agronomic playbooks.',
      capabilities: [
        'Multilingual dialogue support handling local agrarian terminology.',
        'Generates actionable 4-step execution checklists for field hands.',
        'Provides pro-agronomist cost-saving tips on natural composts and bio-stimulants.',
        'Maintains farm memory across sowing, weeding, flowering, and harvest.',
      ],
      sampleOutput: 'Advisor: Early morning leaf dew inspection recommended. Prepare neem oil solution (10,000 ppm) at 3ml/L; spray undersides of foliage using fine mist nozzle.',
    },
  ];

  return (
    <div className="min-h-[640px] h-full flex flex-col justify-between rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
            <span className="text-emerald-400 font-semibold">Slide 05</span>
            <span aria-hidden="true">·</span>
            <span>Key Features</span>
            <span aria-hidden="true">·</span>
            <span>Five Core Modules</span>
          </div>
          <div className="text-xs font-mono text-emerald-400">
            <span>Modular Precision Stack</span>
          </div>
        </div>

        <div className="max-w-3xl">
          <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display">
            Key Features: The Five Agronomy Pillars
          </h2>
          <p className="mt-3 text-stone-300 text-sm sm:text-base leading-relaxed">
            Five synchronized AI modules covering the entire crop lifecycle from pre-sowing soil chemistry to harvest pathology.
          </p>
        </div>
      </div>

      {/* Feature Selector Tabs */}
      <div className="my-5 flex flex-wrap gap-2 p-1.5 rounded-xl bg-stone-950 border border-stone-800">
        {features.map((f, idx) => {
          const isSelected = selectedFeature === idx;
          return (
            <button
              key={f.id}
              onClick={() => setSelectedFeature(idx)}
              className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-lg text-xs font-medium transition-all cursor-pointer flex items-center justify-center gap-2 ${
                isSelected
                  ? 'bg-stone-800 text-white shadow-xs border border-stone-700'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900/60'
              }`}
            >
              <span>{f.icon}</span>
              <span className="font-semibold">{f.title}</span>
            </button>
          );
        })}
      </div>

      {/* Active Feature Deep Dive Showcase Card */}
      {(() => {
        const feat = features[selectedFeature];
        return (
          <div className="p-6 rounded-xl border border-stone-800 bg-stone-950/80 flex flex-col lg:flex-row items-start justify-between gap-6">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-3xl">{feat.icon}</span>
                <div>
                  <h3 className="text-lg font-bold text-white font-display">
                    {feat.title}
                  </h3>
                  <div className="text-xs text-emerald-400 font-medium">
                    {feat.tagline}
                  </div>
                </div>
              </div>

              <p className="mt-3 text-xs sm:text-sm text-stone-300 leading-relaxed max-w-2xl">
                {feat.description}
              </p>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {feat.capabilities.map((cap, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-lg bg-stone-900/70 border border-stone-800/80 text-xs text-stone-200 flex items-start gap-2"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{cap}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Live Model Output Preview Box */}
            <div className="w-full lg:w-80 shrink-0 p-4 rounded-xl border border-emerald-950/80 bg-stone-900/90 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 mb-2">
                  <span>LIVE OUTPUT SCHEMA</span>
                  <span>{feat.badge}</span>
                </div>
                <div className="p-3 rounded-lg bg-stone-950 border border-stone-800 text-xs font-mono text-stone-300 leading-relaxed">
                  {feat.sampleOutput}
                </div>
              </div>

              <button
                onClick={onOpenLiveDemo}
                className="mt-4 w-full py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Test in Live Assistant Sandbox</span>
              </button>
            </div>
          </div>
        );
      })()}

      {/* Slide Footer */}
      <div className="mt-5 pt-4 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
        <div>
          <span>Integrated Stack: Vision + Agronomy Rules + Generative Guidance</span>
        </div>
        <button
          onClick={onNextSlide}
          className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-medium transition-colors cursor-pointer"
        >
          <span>Next: How The System Works</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
