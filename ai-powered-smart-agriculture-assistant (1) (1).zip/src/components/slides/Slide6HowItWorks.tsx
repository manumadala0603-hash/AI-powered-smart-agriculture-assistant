import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, ChevronRight, Play, Camera, Database, Cpu, FileCheck, ThumbsUp } from 'lucide-react';

interface SlideProps {
  onOpenLiveDemo: () => void;
  onNextSlide: () => void;
}

export const Slide6HowItWorks: React.FC<SlideProps> = ({ onOpenLiveDemo, onNextSlide }) => {
  const [activeStep, setActiveStep] = useState<number>(0);

  const steps = [
    {
      num: '01',
      title: 'Farmer Input',
      sub: 'Zero Friction Capture',
      icon: <Camera className="w-5 h-5 text-emerald-400" />,
      tag: 'Step 1: Point & Capture',
      description: 'The farmer snaps a photo of a symptomatic crop leaf, enters soil NPK or voice-records observed farming conditions in their native regional language.',
      details: [
        'Supports standard entry-level smartphone cameras and offline caching.',
        'Audio voice prompt processing for low-literacy rural demographics.',
        'GPS geotagging automatically binds regional micro-soil survey data.',
      ],
      stateText: 'Input Received: Leaf macro-photo + Location Pin',
    },
    {
      num: '02',
      title: 'Data Collection',
      sub: 'Contextual Ingestion',
      icon: <Database className="w-5 h-5 text-teal-400" />,
      tag: 'Step 2: Automated Fusion',
      description: 'System automatically collates live meteorological radar telemetry, historical regional soil maps, and regional crop phenology calendars.',
      details: [
        'Hourly humidity, rainfall probability, and wind velocity ingestion.',
        'Historical agricultural database lookup for soil mineral baseline.',
        'Current crop age and growing stage classification.',
      ],
      stateText: 'Synthesized: 4 Data Vectors Assembled',
    },
    {
      num: '03',
      title: 'AI Analysis',
      sub: 'Multimodal Neural Inference',
      icon: <Cpu className="w-5 h-5 text-lime-400" />,
      tag: 'Step 3: Dual-Core Processing',
      description: 'Gemini 3.8 Flash Vision performs pathological lesion segmentation while the agronomic reasoning engine calculates chemical stoichiometry.',
      details: [
        'Top-1 pathogen classification (Fungal / Bacterial / Viral / Deficiency).',
        'Calculation of transmission risk index and crop loss projection.',
        'Evaluation of microclimate spray window safety parameters.',
      ],
      stateText: 'Model Inference: 96.4% Pathogen Confidence',
    },
    {
      num: '04',
      title: 'Recommendation',
      sub: 'Actionable Prescription',
      icon: <FileCheck className="w-5 h-5 text-sky-400" />,
      tag: 'Step 4: Prescriptive Generation',
      description: 'Generates a clear, color-coded farm advisory: organic remedies, exact chemical dosages, safety intervals, and timing instructions.',
      details: [
        'Organic biocontrols (e.g. Trichoderma, Bacillus, Neem extracts).',
        'Calibrated chemical fungicide/insecticide dosage per liter of water.',
        'Precise spray hour window avoiding wind drift and rain wash-off.',
      ],
      stateText: 'Advisory Generated: 4-Step Checklist + Spray Timing',
    },
    {
      num: '05',
      title: 'Farmer Action',
      sub: 'Execution & Closed Loop',
      icon: <ThumbsUp className="w-5 h-5 text-amber-400" />,
      tag: 'Step 5: Field Execution & Feedback',
      description: 'Farmer executes the treatment checklist. A 5-day follow-up photo prompt tracks pathogen remission and updates regional outbreak alerts.',
      details: [
        'Step-by-step checklist with simple visual dos-and-don\'ts.',
        'Remission verification photo upload at Day 5 to confirm cure.',
        'Anonymized crowd-sourced telemetry updates regional pest maps.',
      ],
      stateText: 'Feedback Loop: Crop Yield Protected',
    },
  ];

  return (
    <div className="min-h-[640px] h-full flex flex-col justify-between rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
            <span className="text-emerald-400 font-semibold">Slide 06</span>
            <span aria-hidden="true">·</span>
            <span>How the System Works</span>
            <span aria-hidden="true">·</span>
            <span>5-Stage Operational Pipeline</span>
          </div>
          <div className="text-xs font-mono text-emerald-400">
            <span>Closed-Loop Farm Intelligence</span>
          </div>
        </div>

        <div className="max-w-3xl">
          <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display">
            How the System Works: The 5-Stage Workflow
          </h2>
          <p className="mt-3 text-stone-300 text-sm sm:text-base leading-relaxed">
            From initial photo capture in the field to verified pathogen remission, every stage is optimized for rapid execution and zero farmer friction.
          </p>
        </div>
      </div>

      {/* 5-Step Horizontal Flow Indicator */}
      <div className="my-6 grid grid-cols-1 md:grid-cols-5 gap-3">
        {steps.map((st, idx) => {
          const isActive = activeStep === idx;
          return (
            <button
              key={st.num}
              onClick={() => setActiveStep(idx)}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                isActive
                  ? 'border-emerald-500 bg-stone-950 shadow-md ring-1 ring-emerald-500/20'
                  : 'border-stone-800 bg-stone-950/40 hover:border-stone-700 hover:bg-stone-950/70'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-2 rounded-lg bg-stone-900 border border-stone-800">
                    {st.icon}
                  </div>
                  <span className="text-xs font-mono font-bold text-stone-500">
                    {st.num}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-stone-100 font-display">
                  {st.title}
                </h3>
                <div className="text-[11px] text-stone-400 mt-0.5">
                  {st.sub}
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-stone-800/80 text-[11px] font-medium flex items-center justify-between">
                <span className={isActive ? 'text-emerald-400' : 'text-stone-500'}>
                  {isActive ? 'Active Phase' : 'View Step'}
                </span>
                <ChevronRight className="w-3.5 h-3.5 text-stone-500" />
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Step Detailed Walkthrough */}
      {(() => {
        const current = steps[activeStep];
        return (
          <div className="p-6 rounded-xl border border-stone-800 bg-stone-950/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex-1">
              <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
                {current.tag}
              </div>
              <h4 className="text-base font-bold text-white mb-2 font-display">
                {current.title}: {current.sub}
              </h4>
              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed max-w-2xl">
                {current.description}
              </p>

              <div className="mt-3 flex flex-wrap gap-2">
                {current.details.map((d, i) => (
                  <span
                    key={i}
                    className="inline-flex items-center gap-1.5 text-xs text-stone-300 bg-stone-900/80 px-2.5 py-1 rounded-md border border-stone-800"
                  >
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>{d}</span>
                  </span>
                ))}
              </div>
            </div>

            <div className="w-full md:w-72 shrink-0 p-4 rounded-xl border border-stone-800 bg-stone-900/90">
              <div className="text-[11px] font-mono text-stone-400 uppercase tracking-wider mb-1">
                PIPELINE STATE
              </div>
              <div className="text-xs font-semibold text-emerald-300 font-mono">
                {current.stateText}
              </div>
              <div className="mt-3 pt-3 border-t border-stone-800 text-[11px] text-stone-400">
                Turnaround latency: <span className="text-stone-200 font-mono font-medium">&lt; 1.8 seconds</span>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Slide Footer */}
      <div className="mt-5 pt-4 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
        <div>
          <span>Pipeline: Farmer Input → Data Collection → AI Analysis → Recommendation → Farmer Action</span>
        </div>
        <button
          onClick={onNextSlide}
          className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-medium transition-colors cursor-pointer"
        >
          <span>Next: Expected Impact</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
