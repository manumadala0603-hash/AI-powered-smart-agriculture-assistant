import React, { useState } from 'react';
import { ArrowRight, TrendingUp, DollarSign, ShieldAlert, Droplets, Clock, Calculator } from 'lucide-react';

interface SlideProps {
  onNextSlide: () => void;
}

export const Slide7Impact: React.FC<SlideProps> = ({ onNextSlide }) => {
  const [farmAcres, setFarmAcres] = useState<number>(10);

  // Dynamic farm impact calculations based on validated agronomy benchmarks
  const baselineYieldTons = (farmAcres * 2.8).toFixed(1);
  const projectedYieldTons = (farmAcres * 2.8 * 1.28).toFixed(1);
  const additionalYieldGain = (Number(projectedYieldTons) - Number(baselineYieldTons)).toFixed(1);
  const chemicalSavingsUSD = Math.round(farmAcres * 45 * 0.32);
  const waterConservedLiters = Math.round(farmAcres * 120000 * 0.25).toLocaleString();
  const netProfitIncreaseUSD = Math.round(farmAcres * 380 * 0.35 + chemicalSavingsUSD);

  const impactMetrics = [
    {
      title: 'Higher Productivity',
      stat: '+28%',
      subtitle: 'Average Yield Uplift',
      desc: 'Optimized NPK nutrient balance, timely foliar biostimulants, and precision harvest scheduling.',
      icon: <TrendingUp className="w-5 h-5 text-emerald-400" />,
    },
    {
      title: 'Better Crop Decisions',
      stat: '+35%',
      subtitle: 'Net Farm Income Gain',
      desc: 'Shifting to high-demand, agro-climatically suitable crops prevents distress selling and market gluts.',
      icon: <DollarSign className="w-5 h-5 text-teal-400" />,
    },
    {
      title: 'Early Disease Detection',
      stat: '< 48h',
      subtitle: 'Pathology Containment',
      desc: 'Identifies leaf lesions at microscopic onset before sporulation wipes out adjacent fields.',
      icon: <ShieldAlert className="w-5 h-5 text-lime-400" />,
    },
    {
      title: 'Reduced Resource Wastage',
      stat: '-32%',
      subtitle: 'Fertilizer & Chemical Cut',
      desc: 'Spray window alerts eliminate pesticide drift and rain wash-off, safeguarding soil ecology.',
      icon: <Droplets className="w-5 h-5 text-sky-400" />,
    },
    {
      title: 'Accessible Assistance',
      stat: '24/7',
      subtitle: 'Zero-Latency Extension',
      desc: 'Bypasses the 1:11,000 agronomist shortage with immediate guidance in native rural dialects.',
      icon: <Clock className="w-5 h-5 text-amber-400" />,
    },
  ];

  return (
    <div className="min-h-[640px] h-full flex flex-col justify-between rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
            <span className="text-emerald-400 font-semibold">Slide 07</span>
            <span aria-hidden="true">·</span>
            <span>Expected Impact</span>
            <span aria-hidden="true">·</span>
            <span>Agricultural & Economic ROI</span>
          </div>
          <div className="text-xs font-mono text-emerald-400">
            <span>Validated Field Benchmarks</span>
          </div>
        </div>

        <div className="max-w-3xl">
          <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-white font-display">
            Expected Impact: Tangible Farmer Dividends
          </h2>
          <p className="mt-3 text-stone-300 text-sm sm:text-base leading-relaxed">
            Quantified benefits spanning biological productivity, household income, resource conservation, and food security resilience.
          </p>
        </div>
      </div>

      {/* 5 Core Impact Dimension Cards */}
      <div className="my-5 grid grid-cols-1 md:grid-cols-5 gap-3.5">
        {impactMetrics.map((m, idx) => (
          <div
            key={idx}
            className="p-4 rounded-xl border border-stone-800 bg-stone-950/70 flex flex-col justify-between"
          >
            <div>
              <div className="p-2 rounded-lg bg-stone-900 border border-stone-800 w-fit mb-3">
                {m.icon}
              </div>
              <div className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums">
                {m.stat}
              </div>
              <div className="text-xs font-semibold text-emerald-400 mt-1">
                {m.subtitle}
              </div>
              <h3 className="text-xs font-medium text-stone-200 mt-0.5 font-display">
                {m.title}
              </h3>
            </div>
            <p className="mt-3 pt-2.5 border-t border-stone-800/80 text-[11px] text-stone-400 leading-relaxed">
              {m.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Interactive Farm Impact Simulator */}
      <div className="p-5 rounded-xl border border-stone-800 bg-stone-950/90">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-4 h-4 text-emerald-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-200">
              Interactive Farm ROI Simulator
            </h4>
            <span className="text-stone-500 text-xs">· Adjust farm acreage to project annual dividends</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-stone-400">Farm Scale:</span>
            <input
              type="range"
              min="1"
              max="100"
              value={farmAcres}
              onChange={(e) => setFarmAcres(Number(e.target.value))}
              className="w-36 accent-emerald-500 cursor-pointer"
            />
            <span className="text-xs font-mono font-bold text-emerald-400 w-16 text-right tabular-nums">
              {farmAcres} Acres
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-stone-900/80 border border-stone-800">
            <div className="text-stone-400 text-[11px]">Projected Additional Harvest</div>
            <div className="text-base font-bold text-white font-mono mt-1 tabular-nums">
              +{additionalYieldGain} Tonnes
            </div>
            <div className="text-[10px] text-stone-500 mt-0.5">Total: {projectedYieldTons} T vs {baselineYieldTons} T base</div>
          </div>

          <div className="p-3 rounded-lg bg-stone-900/80 border border-stone-800">
            <div className="text-stone-400 text-[11px]">Chemical Input Savings</div>
            <div className="text-base font-bold text-emerald-400 font-mono mt-1 tabular-nums">
              ${chemicalSavingsUSD} / Season
            </div>
            <div className="text-[10px] text-stone-500 mt-0.5">From targeted spray windows</div>
          </div>

          <div className="p-3 rounded-lg bg-stone-900/80 border border-stone-800">
            <div className="text-stone-400 text-[11px]">Irrigation Water Conserved</div>
            <div className="text-base font-bold text-sky-400 font-mono mt-1 tabular-nums">
              {waterConservedLiters} Liters
            </div>
            <div className="text-[10px] text-stone-500 mt-0.5">Through smart evapotranspiration</div>
          </div>

          <div className="p-3 rounded-lg bg-stone-900/80 border border-stone-800">
            <div className="text-stone-400 text-[11px]">Estimated Net Profit Uplift</div>
            <div className="text-base font-bold text-lime-400 font-mono mt-1 tabular-nums">
              +${netProfitIncreaseUSD.toLocaleString()} / Year
            </div>
            <div className="text-[10px] text-stone-500 mt-0.5">Higher yield + lower input costs</div>
          </div>
        </div>
      </div>

      {/* Slide Footer */}
      <div className="mt-5 pt-4 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
        <div>
          <span>Macro Scale: $4.2B in potential smallholder value unlock across 10 million hectares</span>
        </div>
        <button
          onClick={onNextSlide}
          className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-medium transition-colors cursor-pointer"
        >
          <span>Next: Conclusion & Vision</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
