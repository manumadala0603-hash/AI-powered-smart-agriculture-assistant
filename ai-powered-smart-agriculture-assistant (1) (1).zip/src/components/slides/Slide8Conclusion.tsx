import React from 'react';
import { Sparkles, ArrowLeft, CheckCircle2, ShieldCheck, HeartHandshake, Compass, RotateCcw } from 'lucide-react';

interface SlideProps {
  onOpenLiveDemo: () => void;
  onResetToSlide1: () => void;
}

export const Slide8Conclusion: React.FC<SlideProps> = ({ onOpenLiveDemo, onResetToSlide1 }) => {
  return (
    <div className="relative min-h-[640px] h-full flex flex-col justify-between overflow-hidden rounded-2xl border border-stone-800 bg-stone-900/60 p-8 md:p-12">
      {/* Background Graphic with subtle contrast scrim */}
      <div className="absolute inset-0 z-0 opacity-20 overflow-hidden">
        <img
          src="/src/assets/images/farmer_guidance_field_1791353129757.jpg"
          alt="Farmer guidance in field"
          className="w-full h-full object-cover object-center"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/85 to-stone-950/50" />
      </div>

      {/* Header */}
      <div className="relative z-10">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-400">
            <span className="text-emerald-400 font-semibold">Slide 08</span>
            <span aria-hidden="true">·</span>
            <span>Conclusion & Vision</span>
            <span aria-hidden="true">·</span>
            <span>Hackathon Summary</span>
          </div>
          <div className="text-xs text-emerald-400 font-mono">
            <span>Production-Ready Multimodal Architecture</span>
          </div>
        </div>
      </div>

      {/* Main Conclusion Hero & Exact User Prompt Quote */}
      <div className="relative z-10 my-auto py-6 max-w-4xl">
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-4 bg-emerald-950/60 px-3 py-1 rounded-md border border-emerald-800/80">
          <HeartHandshake className="w-3.5 h-3.5 text-emerald-400" />
          <span>Core Mission & Declaration</span>
        </div>

        <blockquote className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white font-display leading-tight text-balance">
          “Empowering farmers with AI for <br className="hidden sm:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-lime-300">
            smarter, healthier and more sustainable
          </span>{' '}
          agriculture.”
        </blockquote>

        <p className="mt-5 text-sm sm:text-base text-stone-300 leading-relaxed max-w-3xl text-balance">
          Our AI-Powered Smart Agriculture Assistant closes the rural knowledge gap. By unifying computer vision pathology, microclimate forecasting, soil chemistry, and empathetic conversational guidance, we place a master agronomist into the hands of every farmer.
        </p>

        {/* 4 Pillars of Hackathon Delivery */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="text-xs font-bold text-emerald-400 mb-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Multimodal AI
            </div>
            <p className="text-xs text-stone-400 leading-snug">
              Gemini 3.8 Flash Vision for instant, accurate leaf pathology and disease diagnosis.
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="text-xs font-bold text-teal-400 mb-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Agro-Optimization
            </div>
            <p className="text-xs text-stone-400 leading-snug">
              Stoichiometric soil balancing & microclimate spray window forecasting.
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="text-xs font-bold text-lime-400 mb-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Vernacular First
            </div>
            <p className="text-xs text-stone-400 leading-snug">
              Voice-enabled, multilingual natural language guidance for rural growers.
            </p>
          </div>

          <div className="p-3.5 rounded-xl border border-stone-800 bg-stone-950/80">
            <div className="text-xs font-bold text-amber-400 mb-1 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Sustainable ROI
            </div>
            <p className="text-xs text-stone-400 leading-snug">
              +28% average yield uplift with 32% reduction in chemical waste.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-wrap items-center gap-4">
          <button
            onClick={onOpenLiveDemo}
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition-colors cursor-pointer whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4" />
            <span>Launch Live Assistant Sandbox</span>
          </button>

          <button
            onClick={onResetToSlide1}
            className="inline-flex items-center gap-2 px-4 py-3 text-sm font-medium rounded-lg border border-stone-700 bg-stone-800/80 hover:bg-stone-800 text-stone-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart Presentation (Slide 01)</span>
          </button>
        </div>
      </div>

      {/* Slide Footer */}
      <div className="relative z-10 pt-4 border-t border-stone-800 flex flex-wrap items-center justify-between gap-4 text-xs text-stone-400">
        <div className="flex items-center gap-2">
          <span>AI-Powered Smart Agriculture Assistant</span>
          <span aria-hidden="true">·</span>
          <span>Hackathon Final Pitch</span>
        </div>
        <div className="flex items-center gap-1.5 text-stone-300">
          <span>Ready for Q&A with Judges</span>
        </div>
      </div>
    </div>
  );
};
