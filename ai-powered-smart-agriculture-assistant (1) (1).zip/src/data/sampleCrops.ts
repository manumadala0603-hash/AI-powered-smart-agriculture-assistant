import { SampleCropCase } from '../types';

export const SAMPLE_CROP_CASES: SampleCropCase[] = [
  {
    id: 'tomato-blight',
    cropName: 'Tomato',
    diseaseLabel: 'Late Blight (Phytophthora infestans)',
    symptoms: 'Dark water-soaked lesions on leaf margins with white downy fungal sporulation on undersides after humid rainfall.',
    image: '/src/assets/images/crop_disease_leaves_1791353101307.jpg',
    badge: 'High Risk / Immediate Action',
  },
  {
    id: 'rice-blast',
    cropName: 'Paddy Rice',
    diseaseLabel: 'Rice Blast (Pyricularia oryzae)',
    symptoms: 'Spindle-shaped necrotic lesions with diamond grey centers and brownish-red borders on upper flag leaves.',
    image: '/src/assets/images/hero_smart_agriculture_1791353087287.jpg',
    badge: 'Severe Vascular Infection',
  },
  {
    id: 'maize-leaf-spot',
    cropName: 'Maize / Corn',
    diseaseLabel: 'Northern Leaf Blight (Exserohilum turcicum)',
    symptoms: 'Elongated grayish-green elliptical cigar-shaped lesions progressing along parallel leaf veins.',
    image: '/src/assets/images/soil_sensor_analysis_1791353118266.jpg',
    badge: 'Moderate Sporulation',
  },
  {
    id: 'apple-scab',
    cropName: 'Apple Foliage',
    diseaseLabel: 'Apple Scab (Venturia inaequalis)',
    symptoms: 'Velvety olive-green to black fungal spots on upper leaf surfaces causing premature yellowing and leaf drop.',
    image: '/src/assets/images/farmer_guidance_field_1791353129757.jpg',
    badge: 'Seasonal Spore Spread',
  },
];
