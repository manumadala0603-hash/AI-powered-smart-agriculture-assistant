export interface SlideData {
  id: number;
  number: number;
  title: string;
  subtitle: string;
  category: string;
  speakerNotes: string[];
}

export interface DiseaseDiagnosis {
  diseaseName: string;
  scientificName: string;
  severity: 'Low' | 'Moderate' | 'Severe';
  confidence: number;
  pathogenType: string;
  immediateActions: string[];
  organicTreatment: string;
  chemicalTreatment: string;
  preventiveMeasures: string[];
  advisorySummary: string;
}

export interface RecommendedCrop {
  crop: string;
  suitabilityScore: number;
  expectedYield: string;
  growthDurationDays: number;
  waterRequirement: 'Low' | 'Moderate' | 'High';
  marketOutlook: string;
  keyPrecautions: string;
}

export interface RecommendationResponse {
  recommendedCrops: RecommendedCrop[];
  soilHealthNote: string;
  fertilizerAdjustment: string;
}

export interface FarmingAdvisorResponse {
  answer: string;
  actionChecklist: string[];
  expertTip: string;
  resourcesNeeded: string[];
}

export interface SampleCropCase {
  id: string;
  cropName: string;
  diseaseLabel: string;
  symptoms: string;
  image: string;
  badge: string;
}
